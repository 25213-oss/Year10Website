gdjs.lvl_321Code = {};
gdjs.lvl_321Code.localVariables = [];
gdjs.lvl_321Code.idToCallbackMap = new Map();
gdjs.lvl_321Code.GDHouse_9595tall_9595backgroundObjects1= [];
gdjs.lvl_321Code.GDHouse_9595tall_9595backgroundObjects2= [];
gdjs.lvl_321Code.GDHouse_9595tall_9595foregroundObjects1= [];
gdjs.lvl_321Code.GDHouse_9595tall_9595foregroundObjects2= [];
gdjs.lvl_321Code.GDHouseObjects1= [];
gdjs.lvl_321Code.GDHouseObjects2= [];
gdjs.lvl_321Code.GDMerged_9595Full_9595BackgroundObjects1= [];
gdjs.lvl_321Code.GDMerged_9595Full_9595BackgroundObjects2= [];
gdjs.lvl_321Code.GDHouse_9595small_9595backgroundObjects1= [];
gdjs.lvl_321Code.GDHouse_9595small_9595backgroundObjects2= [];
gdjs.lvl_321Code.GDBridge_9595HandleObjects1= [];
gdjs.lvl_321Code.GDBridge_9595HandleObjects2= [];
gdjs.lvl_321Code.GDBridge_9595SupportObjects1= [];
gdjs.lvl_321Code.GDBridge_9595SupportObjects2= [];
gdjs.lvl_321Code.GDBridgeObjects1= [];
gdjs.lvl_321Code.GDBridgeObjects2= [];
gdjs.lvl_321Code.GDCave_9595Background_9595HoleObjects1= [];
gdjs.lvl_321Code.GDCave_9595Background_9595HoleObjects2= [];
gdjs.lvl_321Code.GDCave_9595BackgroundObjects1= [];
gdjs.lvl_321Code.GDCave_9595BackgroundObjects2= [];
gdjs.lvl_321Code.GDCave_9595EntranceObjects1= [];
gdjs.lvl_321Code.GDCave_9595EntranceObjects2= [];
gdjs.lvl_321Code.GDLamp_9595leftObjects1= [];
gdjs.lvl_321Code.GDLamp_9595leftObjects2= [];
gdjs.lvl_321Code.GDLamp_9595rightObjects1= [];
gdjs.lvl_321Code.GDLamp_9595rightObjects2= [];
gdjs.lvl_321Code.GDBush_9595BackgroundObjects1= [];
gdjs.lvl_321Code.GDBush_9595BackgroundObjects2= [];
gdjs.lvl_321Code.GDBush_9595Background_9595ShadowObjects1= [];
gdjs.lvl_321Code.GDBush_9595Background_9595ShadowObjects2= [];
gdjs.lvl_321Code.GDGrass_9595backgroundObjects1= [];
gdjs.lvl_321Code.GDGrass_9595backgroundObjects2= [];
gdjs.lvl_321Code.GDBush_9595foregroundObjects1= [];
gdjs.lvl_321Code.GDBush_9595foregroundObjects2= [];
gdjs.lvl_321Code.GDMushroomsObjects1= [];
gdjs.lvl_321Code.GDMushroomsObjects2= [];
gdjs.lvl_321Code.GDGrass_9595foregroundObjects1= [];
gdjs.lvl_321Code.GDGrass_9595foregroundObjects2= [];
gdjs.lvl_321Code.GDTile_95951Objects1= [];
gdjs.lvl_321Code.GDTile_95951Objects2= [];
gdjs.lvl_321Code.GDCave_9595Under_9595TileObjects1= [];
gdjs.lvl_321Code.GDCave_9595Under_9595TileObjects2= [];
gdjs.lvl_321Code.GDTile_959511Objects1= [];
gdjs.lvl_321Code.GDTile_959511Objects2= [];
gdjs.lvl_321Code.GDTile_959512Objects1= [];
gdjs.lvl_321Code.GDTile_959512Objects2= [];
gdjs.lvl_321Code.GDTile_959514Objects1= [];
gdjs.lvl_321Code.GDTile_959514Objects2= [];
gdjs.lvl_321Code.GDTile_959516Objects1= [];
gdjs.lvl_321Code.GDTile_959516Objects2= [];
gdjs.lvl_321Code.GDTile_959517Objects1= [];
gdjs.lvl_321Code.GDTile_959517Objects2= [];
gdjs.lvl_321Code.GDTile_959513Objects1= [];
gdjs.lvl_321Code.GDTile_959513Objects2= [];
gdjs.lvl_321Code.GDTile_959515Objects1= [];
gdjs.lvl_321Code.GDTile_959515Objects2= [];
gdjs.lvl_321Code.GDTile_959518Objects1= [];
gdjs.lvl_321Code.GDTile_959518Objects2= [];
gdjs.lvl_321Code.GDTile_959519Objects1= [];
gdjs.lvl_321Code.GDTile_959519Objects2= [];
gdjs.lvl_321Code.GDTile_95952Objects1= [];
gdjs.lvl_321Code.GDTile_95952Objects2= [];
gdjs.lvl_321Code.GDTile_959520Objects1= [];
gdjs.lvl_321Code.GDTile_959520Objects2= [];
gdjs.lvl_321Code.GDTile_959521Objects1= [];
gdjs.lvl_321Code.GDTile_959521Objects2= [];
gdjs.lvl_321Code.GDTile_959522Objects1= [];
gdjs.lvl_321Code.GDTile_959522Objects2= [];
gdjs.lvl_321Code.GDTile_959523Objects1= [];
gdjs.lvl_321Code.GDTile_959523Objects2= [];
gdjs.lvl_321Code.GDTile_959524Objects1= [];
gdjs.lvl_321Code.GDTile_959524Objects2= [];
gdjs.lvl_321Code.GDTile_959527Objects1= [];
gdjs.lvl_321Code.GDTile_959527Objects2= [];
gdjs.lvl_321Code.GDTile_959525Objects1= [];
gdjs.lvl_321Code.GDTile_959525Objects2= [];
gdjs.lvl_321Code.GDTile_959528Objects1= [];
gdjs.lvl_321Code.GDTile_959528Objects2= [];
gdjs.lvl_321Code.GDTile_959531Objects1= [];
gdjs.lvl_321Code.GDTile_959531Objects2= [];
gdjs.lvl_321Code.GDTile_959529Objects1= [];
gdjs.lvl_321Code.GDTile_959529Objects2= [];
gdjs.lvl_321Code.GDTile_959532Objects1= [];
gdjs.lvl_321Code.GDTile_959532Objects2= [];
gdjs.lvl_321Code.GDTile_959535Objects1= [];
gdjs.lvl_321Code.GDTile_959535Objects2= [];
gdjs.lvl_321Code.GDTile_959536Objects1= [];
gdjs.lvl_321Code.GDTile_959536Objects2= [];
gdjs.lvl_321Code.GDTile_959537Objects1= [];
gdjs.lvl_321Code.GDTile_959537Objects2= [];
gdjs.lvl_321Code.GDTile_95957Objects1= [];
gdjs.lvl_321Code.GDTile_95957Objects2= [];
gdjs.lvl_321Code.GDTile_95958Objects1= [];
gdjs.lvl_321Code.GDTile_95958Objects2= [];
gdjs.lvl_321Code.GDBatObjects1= [];
gdjs.lvl_321Code.GDBatObjects2= [];
gdjs.lvl_321Code.GDTile_95959Objects1= [];
gdjs.lvl_321Code.GDTile_95959Objects2= [];
gdjs.lvl_321Code.GDDark_9595GuardObjects1= [];
gdjs.lvl_321Code.GDDark_9595GuardObjects2= [];
gdjs.lvl_321Code.GDBoss_9595GolemObjects1= [];
gdjs.lvl_321Code.GDBoss_9595GolemObjects2= [];
gdjs.lvl_321Code.GDForest_9595Goblin_9595HogObjects1= [];
gdjs.lvl_321Code.GDForest_9595Goblin_9595HogObjects2= [];
gdjs.lvl_321Code.GDForest_9595GoblinObjects1= [];
gdjs.lvl_321Code.GDForest_9595GoblinObjects2= [];
gdjs.lvl_321Code.GDFrogObjects1= [];
gdjs.lvl_321Code.GDFrogObjects2= [];
gdjs.lvl_321Code.GDMushroomObjects1= [];
gdjs.lvl_321Code.GDMushroomObjects2= [];
gdjs.lvl_321Code.GDFrog_9595TongueObjects1= [];
gdjs.lvl_321Code.GDFrog_9595TongueObjects2= [];
gdjs.lvl_321Code.GDNecromancerObjects1= [];
gdjs.lvl_321Code.GDNecromancerObjects2= [];
gdjs.lvl_321Code.GDSkull_9595SlimeObjects1= [];
gdjs.lvl_321Code.GDSkull_9595SlimeObjects2= [];
gdjs.lvl_321Code.GDPlant_9595MutantObjects1= [];
gdjs.lvl_321Code.GDPlant_9595MutantObjects2= [];
gdjs.lvl_321Code.GDbarnacleObjects1= [];
gdjs.lvl_321Code.GDbarnacleObjects2= [];
gdjs.lvl_321Code.GDcharacter_9595yellowObjects1= [];
gdjs.lvl_321Code.GDcharacter_9595yellowObjects2= [];
gdjs.lvl_321Code.GDcharacter_9595pinkObjects1= [];
gdjs.lvl_321Code.GDcharacter_9595pinkObjects2= [];
gdjs.lvl_321Code.GDcharacter_9595beigeObjects1= [];
gdjs.lvl_321Code.GDcharacter_9595beigeObjects2= [];
gdjs.lvl_321Code.GDcharacter_9595purpleObjects1= [];
gdjs.lvl_321Code.GDcharacter_9595purpleObjects2= [];
gdjs.lvl_321Code.GDcharacter_9595greenObjects1= [];
gdjs.lvl_321Code.GDcharacter_9595greenObjects2= [];
gdjs.lvl_321Code.GDbeeObjects1= [];
gdjs.lvl_321Code.GDbeeObjects2= [];
gdjs.lvl_321Code.GDfish_9595yellowObjects1= [];
gdjs.lvl_321Code.GDfish_9595yellowObjects2= [];
gdjs.lvl_321Code.GDfish_9595blueObjects1= [];
gdjs.lvl_321Code.GDfish_9595blueObjects2= [];
gdjs.lvl_321Code.GDfish_9595purpleObjects1= [];
gdjs.lvl_321Code.GDfish_9595purpleObjects2= [];
gdjs.lvl_321Code.GDblockObjects1= [];
gdjs.lvl_321Code.GDblockObjects2= [];
gdjs.lvl_321Code.GDflyObjects1= [];
gdjs.lvl_321Code.GDflyObjects2= [];
gdjs.lvl_321Code.GDfrogObjects1= [];
gdjs.lvl_321Code.GDfrogObjects2= [];
gdjs.lvl_321Code.GDsawObjects1= [];
gdjs.lvl_321Code.GDsawObjects2= [];
gdjs.lvl_321Code.GDmouseObjects1= [];
gdjs.lvl_321Code.GDmouseObjects2= [];
gdjs.lvl_321Code.GDladybugObjects1= [];
gdjs.lvl_321Code.GDladybugObjects2= [];
gdjs.lvl_321Code.GDslime_9595blockObjects1= [];
gdjs.lvl_321Code.GDslime_9595blockObjects2= [];
gdjs.lvl_321Code.GDslime_9595fireObjects1= [];
gdjs.lvl_321Code.GDslime_9595fireObjects2= [];
gdjs.lvl_321Code.GDslime_9595spikeObjects1= [];
gdjs.lvl_321Code.GDslime_9595spikeObjects2= [];
gdjs.lvl_321Code.GDslime_9595normalObjects1= [];
gdjs.lvl_321Code.GDslime_9595normalObjects2= [];
gdjs.lvl_321Code.GDsnailObjects1= [];
gdjs.lvl_321Code.GDsnailObjects2= [];
gdjs.lvl_321Code.GDworm_9595ringObjects1= [];
gdjs.lvl_321Code.GDworm_9595ringObjects2= [];
gdjs.lvl_321Code.GDworm_9595normalObjects1= [];
gdjs.lvl_321Code.GDworm_9595normalObjects2= [];
gdjs.lvl_321Code.GDhud_9595characterObjects1= [];
gdjs.lvl_321Code.GDhud_9595characterObjects2= [];
gdjs.lvl_321Code.GDhud_9595coinObjects1= [];
gdjs.lvl_321Code.GDhud_9595coinObjects2= [];
gdjs.lvl_321Code.GDhud_9595keyObjects1= [];
gdjs.lvl_321Code.GDhud_9595keyObjects2= [];
gdjs.lvl_321Code.GDhud_9595player_9595helmetObjects1= [];
gdjs.lvl_321Code.GDhud_9595player_9595helmetObjects2= [];
gdjs.lvl_321Code.GDblock_9595coinObjects1= [];
gdjs.lvl_321Code.GDblock_9595coinObjects2= [];
gdjs.lvl_321Code.GDhud_9595heartObjects1= [];
gdjs.lvl_321Code.GDhud_9595heartObjects2= [];
gdjs.lvl_321Code.GDblock_9595exclamationObjects1= [];
gdjs.lvl_321Code.GDblock_9595exclamationObjects2= [];
gdjs.lvl_321Code.GDblock_9595planksObjects1= [];
gdjs.lvl_321Code.GDblock_9595planksObjects2= [];
gdjs.lvl_321Code.GDblock_9595strong_9595coinObjects1= [];
gdjs.lvl_321Code.GDblock_9595strong_9595coinObjects2= [];
gdjs.lvl_321Code.GDhud_9595playerObjects1= [];
gdjs.lvl_321Code.GDhud_9595playerObjects2= [];
gdjs.lvl_321Code.GDblock_9595strong_9595dangerObjects1= [];
gdjs.lvl_321Code.GDblock_9595strong_9595dangerObjects2= [];
gdjs.lvl_321Code.GDblock_9595strong_9595emptyObjects1= [];
gdjs.lvl_321Code.GDblock_9595strong_9595emptyObjects2= [];
gdjs.lvl_321Code.GDblock_9595strong_9595exclamationObjects1= [];
gdjs.lvl_321Code.GDblock_9595strong_9595exclamationObjects2= [];
gdjs.lvl_321Code.GDblock2Objects1= [];
gdjs.lvl_321Code.GDblock2Objects2= [];
gdjs.lvl_321Code.GDbombObjects1= [];
gdjs.lvl_321Code.GDbombObjects2= [];
gdjs.lvl_321Code.GDbridgeObjects1= [];
gdjs.lvl_321Code.GDbridgeObjects2= [];
gdjs.lvl_321Code.GDbricksObjects1= [];
gdjs.lvl_321Code.GDbricksObjects2= [];
gdjs.lvl_321Code.GDcactusObjects1= [];
gdjs.lvl_321Code.GDcactusObjects2= [];
gdjs.lvl_321Code.GDcoin_9595goldObjects1= [];
gdjs.lvl_321Code.GDcoin_9595goldObjects2= [];
gdjs.lvl_321Code.GDcoin_9595bronzeObjects1= [];
gdjs.lvl_321Code.GDcoin_9595bronzeObjects2= [];
gdjs.lvl_321Code.GDbushObjects1= [];
gdjs.lvl_321Code.GDbushObjects2= [];
gdjs.lvl_321Code.GDconveyorObjects1= [];
gdjs.lvl_321Code.GDconveyorObjects2= [];
gdjs.lvl_321Code.GDcoin_9595silverObjects1= [];
gdjs.lvl_321Code.GDcoin_9595silverObjects2= [];
gdjs.lvl_321Code.GDdoor_9595topObjects1= [];
gdjs.lvl_321Code.GDdoor_9595topObjects2= [];
gdjs.lvl_321Code.GDfenceObjects1= [];
gdjs.lvl_321Code.GDfenceObjects2= [];
gdjs.lvl_321Code.GDfireballObjects1= [];
gdjs.lvl_321Code.GDfireballObjects2= [];
gdjs.lvl_321Code.GDflagObjects1= [];
gdjs.lvl_321Code.GDflagObjects2= [];
gdjs.lvl_321Code.GDgemObjects1= [];
gdjs.lvl_321Code.GDgemObjects2= [];
gdjs.lvl_321Code.GDheartObjects1= [];
gdjs.lvl_321Code.GDheartObjects2= [];
gdjs.lvl_321Code.GDgrassObjects1= [];
gdjs.lvl_321Code.GDgrassObjects2= [];
gdjs.lvl_321Code.GDhillObjects1= [];
gdjs.lvl_321Code.GDhillObjects2= [];
gdjs.lvl_321Code.GDkeyObjects1= [];
gdjs.lvl_321Code.GDkeyObjects2= [];
gdjs.lvl_321Code.GDlavaObjects1= [];
gdjs.lvl_321Code.GDlavaObjects2= [];
gdjs.lvl_321Code.GDleverObjects1= [];
gdjs.lvl_321Code.GDleverObjects2= [];
gdjs.lvl_321Code.GDdoor_9595longObjects1= [];
gdjs.lvl_321Code.GDdoor_9595longObjects2= [];
gdjs.lvl_321Code.GDmushroomObjects1= [];
gdjs.lvl_321Code.GDmushroomObjects2= [];
gdjs.lvl_321Code.GDlockObjects1= [];
gdjs.lvl_321Code.GDlockObjects2= [];
gdjs.lvl_321Code.GDkillboxObjects1= [];
gdjs.lvl_321Code.GDkillboxObjects2= [];
gdjs.lvl_321Code.GDexplosionObjects1= [];
gdjs.lvl_321Code.GDexplosionObjects2= [];
gdjs.lvl_321Code.GDwaypoint_95951_9595Objects1= [];
gdjs.lvl_321Code.GDwaypoint_95951_9595Objects2= [];
gdjs.lvl_321Code.GDAngela_9595DemonObjects1= [];
gdjs.lvl_321Code.GDAngela_9595DemonObjects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95951Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95951Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95952Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95952Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95953Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95953Objects2= [];
gdjs.lvl_321Code.GDBard_95951Objects1= [];
gdjs.lvl_321Code.GDBard_95951Objects2= [];
gdjs.lvl_321Code.GDBard_95952Objects1= [];
gdjs.lvl_321Code.GDBard_95952Objects2= [];
gdjs.lvl_321Code.GDBard_95953Objects1= [];
gdjs.lvl_321Code.GDBard_95953Objects2= [];
gdjs.lvl_321Code.GDBard_95954Objects1= [];
gdjs.lvl_321Code.GDBard_95954Objects2= [];
gdjs.lvl_321Code.GDBard_95955Objects1= [];
gdjs.lvl_321Code.GDBard_95955Objects2= [];
gdjs.lvl_321Code.GDBard_95956Objects1= [];
gdjs.lvl_321Code.GDBard_95956Objects2= [];
gdjs.lvl_321Code.GDBard_95957Objects1= [];
gdjs.lvl_321Code.GDBard_95957Objects2= [];
gdjs.lvl_321Code.GDBard_95958Objects1= [];
gdjs.lvl_321Code.GDBard_95958Objects2= [];
gdjs.lvl_321Code.GDConjurer_95951Objects1= [];
gdjs.lvl_321Code.GDConjurer_95951Objects2= [];
gdjs.lvl_321Code.GDConjurer_95952Objects1= [];
gdjs.lvl_321Code.GDConjurer_95952Objects2= [];
gdjs.lvl_321Code.GDConjurer_95954Objects1= [];
gdjs.lvl_321Code.GDConjurer_95954Objects2= [];
gdjs.lvl_321Code.GDConjurer_95953Objects1= [];
gdjs.lvl_321Code.GDConjurer_95953Objects2= [];
gdjs.lvl_321Code.GDConjurer_95955Objects1= [];
gdjs.lvl_321Code.GDConjurer_95955Objects2= [];
gdjs.lvl_321Code.GDConjurer_95956Objects1= [];
gdjs.lvl_321Code.GDConjurer_95956Objects2= [];
gdjs.lvl_321Code.GDConjurer_95957Objects1= [];
gdjs.lvl_321Code.GDConjurer_95957Objects2= [];
gdjs.lvl_321Code.GDConjurer_95958Objects1= [];
gdjs.lvl_321Code.GDConjurer_95958Objects2= [];
gdjs.lvl_321Code.GDDevout_95952Objects1= [];
gdjs.lvl_321Code.GDDevout_95952Objects2= [];
gdjs.lvl_321Code.GDDevout_95951Objects1= [];
gdjs.lvl_321Code.GDDevout_95951Objects2= [];
gdjs.lvl_321Code.GDDevout_95953Objects1= [];
gdjs.lvl_321Code.GDDevout_95953Objects2= [];
gdjs.lvl_321Code.GDDevout_95954Objects1= [];
gdjs.lvl_321Code.GDDevout_95954Objects2= [];
gdjs.lvl_321Code.GDDevout_95955Objects1= [];
gdjs.lvl_321Code.GDDevout_95955Objects2= [];
gdjs.lvl_321Code.GDDevout_95956Objects1= [];
gdjs.lvl_321Code.GDDevout_95956Objects2= [];
gdjs.lvl_321Code.GDDevout_95957Objects1= [];
gdjs.lvl_321Code.GDDevout_95957Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_959510Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_959510Objects2= [];
gdjs.lvl_321Code.GDDevout_95958Objects1= [];
gdjs.lvl_321Code.GDDevout_95958Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95954Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95954Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95955Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95955Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95956Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95956Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95957Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95957Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95958Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95958Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95959Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_95959Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_959511Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_959511Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_959512Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_959512Objects2= [];
gdjs.lvl_321Code.GDGeneric_9595Character_959513Objects1= [];
gdjs.lvl_321Code.GDGeneric_9595Character_959513Objects2= [];
gdjs.lvl_321Code.GDScout_95951Objects1= [];
gdjs.lvl_321Code.GDScout_95951Objects2= [];
gdjs.lvl_321Code.GDScout_95952Objects1= [];
gdjs.lvl_321Code.GDScout_95952Objects2= [];
gdjs.lvl_321Code.GDScout_95953Objects1= [];
gdjs.lvl_321Code.GDScout_95953Objects2= [];
gdjs.lvl_321Code.GDScout_95954Objects1= [];
gdjs.lvl_321Code.GDScout_95954Objects2= [];
gdjs.lvl_321Code.GDScout_95955Objects1= [];
gdjs.lvl_321Code.GDScout_95955Objects2= [];
gdjs.lvl_321Code.GDScout_95956Objects1= [];
gdjs.lvl_321Code.GDScout_95956Objects2= [];
gdjs.lvl_321Code.GDScout_95957Objects1= [];
gdjs.lvl_321Code.GDScout_95957Objects2= [];
gdjs.lvl_321Code.GDScout_95958Objects1= [];
gdjs.lvl_321Code.GDScout_95958Objects2= [];
gdjs.lvl_321Code.GDSoldier_95951Objects1= [];
gdjs.lvl_321Code.GDSoldier_95951Objects2= [];
gdjs.lvl_321Code.GDSoldier_95952Objects1= [];
gdjs.lvl_321Code.GDSoldier_95952Objects2= [];
gdjs.lvl_321Code.GDSoldier_95954Objects1= [];
gdjs.lvl_321Code.GDSoldier_95954Objects2= [];
gdjs.lvl_321Code.GDSoldier_95953Objects1= [];
gdjs.lvl_321Code.GDSoldier_95953Objects2= [];
gdjs.lvl_321Code.GDSoldier_95955Objects1= [];
gdjs.lvl_321Code.GDSoldier_95955Objects2= [];
gdjs.lvl_321Code.GDSoldier_95956Objects1= [];
gdjs.lvl_321Code.GDSoldier_95956Objects2= [];
gdjs.lvl_321Code.GDSoldier_95957Objects1= [];
gdjs.lvl_321Code.GDSoldier_95957Objects2= [];
gdjs.lvl_321Code.GDSoldier_95958Objects1= [];
gdjs.lvl_321Code.GDSoldier_95958Objects2= [];


gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_321Code.GDScout_95953Objects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDTile_959595958Objects1Objects = Hashtable.newFrom({"Tile_8": gdjs.lvl_321Code.GDTile_95958Objects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDexplosionObjects1Objects = Hashtable.newFrom({"explosion": gdjs.lvl_321Code.GDexplosionObjects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_321Code.GDScout_95953Objects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDkillboxObjects1Objects = Hashtable.newFrom({"killbox": gdjs.lvl_321Code.GDkillboxObjects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_321Code.GDScout_95953Objects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDDark_95959595GuardObjects1Objects = Hashtable.newFrom({"Dark_Guard": gdjs.lvl_321Code.GDDark_9595GuardObjects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDexplosionObjects1Objects = Hashtable.newFrom({"explosion": gdjs.lvl_321Code.GDexplosionObjects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_321Code.GDScout_95953Objects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDkillboxObjects1Objects = Hashtable.newFrom({"killbox": gdjs.lvl_321Code.GDkillboxObjects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_321Code.GDScout_95953Objects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDheartObjects1Objects = Hashtable.newFrom({"heart": gdjs.lvl_321Code.GDheartObjects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDladybugObjects1Objects = Hashtable.newFrom({"ladybug": gdjs.lvl_321Code.GDladybugObjects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_321Code.GDScout_95953Objects1});
gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDHouseObjects1Objects = Hashtable.newFrom({"House": gdjs.lvl_321Code.GDHouseObjects1});
gdjs.lvl_321Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tile_8"), gdjs.lvl_321Code.GDTile_95958Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects, "PlatformerObject", gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDTile_959595958Objects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_321Code.GDTile_95958Objects1 */
{for(var i = 0, len = gdjs.lvl_321Code.GDTile_95958Objects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDTile_95958Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("bomb"), gdjs.lvl_321Code.GDbombObjects1);
gdjs.lvl_321Code.GDexplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDexplosionObjects1Objects, (( gdjs.lvl_321Code.GDbombObjects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDbombObjects1[0].getPointX("")), (( gdjs.lvl_321Code.GDbombObjects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDbombObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.lvl_321Code.GDbombObjects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDbombObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("killbox"), gdjs.lvl_321Code.GDkillboxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects, "PlatformerObject", gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDkillboxObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_321Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_321Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getSceneLoadingProgress(runtimeScene, "lvl 1") == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dark_Guard"), gdjs.lvl_321Code.GDDark_9595GuardObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_321Code.GDDark_9595GuardObjects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDDark_9595GuardObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.lvl_321Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_321Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDScout_95953Objects1[0].getPointY("")));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dark_Guard"), gdjs.lvl_321Code.GDDark_9595GuardObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDDark_95959595GuardObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_321Code.GDDark_9595GuardObjects1 */
/* Reuse gdjs.lvl_321Code.GDScout_95953Objects1 */
gdjs.lvl_321Code.GDexplosionObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_321Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDexplosionObjects1Objects, (( gdjs.lvl_321Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_321Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDScout_95953Objects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.lvl_321Code.GDDark_9595GuardObjects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDDark_9595GuardObjects1[i].rotateTowardPosition((( gdjs.lvl_321Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_321Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDScout_95953Objects1[0].getPointY("")), 11, runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("killbox"), gdjs.lvl_321Code.GDkillboxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDkillboxObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.prioritizeLoadingOfScene(runtimeScene, "lvl 1");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("heart"), gdjs.lvl_321Code.GDheartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDheartObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dark_Guard"), gdjs.lvl_321Code.GDDark_9595GuardObjects1);
/* Reuse gdjs.lvl_321Code.GDheartObjects1 */
gdjs.lvl_321Code.GDladybugObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_321Code.GDDark_9595GuardObjects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDDark_9595GuardObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDladybugObjects1Objects, (( gdjs.lvl_321Code.GDDark_9595GuardObjects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDDark_9595GuardObjects1[0].getPointX("")), (( gdjs.lvl_321Code.GDDark_9595GuardObjects1.length === 0 ) ? 0 :gdjs.lvl_321Code.GDDark_9595GuardObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.lvl_321Code.GDheartObjects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDheartObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("House"), gdjs.lvl_321Code.GDHouseObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_321Code.mapOfGDgdjs_9546lvl_9595321Code_9546GDHouseObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl 2", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_321Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDScout_95953Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_321Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDScout_95953Objects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_321Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_321Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_321Code.GDScout_95953Objects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
}

}


};

gdjs.lvl_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl_321Code.GDHouse_9595tall_9595backgroundObjects1.length = 0;
gdjs.lvl_321Code.GDHouse_9595tall_9595backgroundObjects2.length = 0;
gdjs.lvl_321Code.GDHouse_9595tall_9595foregroundObjects1.length = 0;
gdjs.lvl_321Code.GDHouse_9595tall_9595foregroundObjects2.length = 0;
gdjs.lvl_321Code.GDHouseObjects1.length = 0;
gdjs.lvl_321Code.GDHouseObjects2.length = 0;
gdjs.lvl_321Code.GDMerged_9595Full_9595BackgroundObjects1.length = 0;
gdjs.lvl_321Code.GDMerged_9595Full_9595BackgroundObjects2.length = 0;
gdjs.lvl_321Code.GDHouse_9595small_9595backgroundObjects1.length = 0;
gdjs.lvl_321Code.GDHouse_9595small_9595backgroundObjects2.length = 0;
gdjs.lvl_321Code.GDBridge_9595HandleObjects1.length = 0;
gdjs.lvl_321Code.GDBridge_9595HandleObjects2.length = 0;
gdjs.lvl_321Code.GDBridge_9595SupportObjects1.length = 0;
gdjs.lvl_321Code.GDBridge_9595SupportObjects2.length = 0;
gdjs.lvl_321Code.GDBridgeObjects1.length = 0;
gdjs.lvl_321Code.GDBridgeObjects2.length = 0;
gdjs.lvl_321Code.GDCave_9595Background_9595HoleObjects1.length = 0;
gdjs.lvl_321Code.GDCave_9595Background_9595HoleObjects2.length = 0;
gdjs.lvl_321Code.GDCave_9595BackgroundObjects1.length = 0;
gdjs.lvl_321Code.GDCave_9595BackgroundObjects2.length = 0;
gdjs.lvl_321Code.GDCave_9595EntranceObjects1.length = 0;
gdjs.lvl_321Code.GDCave_9595EntranceObjects2.length = 0;
gdjs.lvl_321Code.GDLamp_9595leftObjects1.length = 0;
gdjs.lvl_321Code.GDLamp_9595leftObjects2.length = 0;
gdjs.lvl_321Code.GDLamp_9595rightObjects1.length = 0;
gdjs.lvl_321Code.GDLamp_9595rightObjects2.length = 0;
gdjs.lvl_321Code.GDBush_9595BackgroundObjects1.length = 0;
gdjs.lvl_321Code.GDBush_9595BackgroundObjects2.length = 0;
gdjs.lvl_321Code.GDBush_9595Background_9595ShadowObjects1.length = 0;
gdjs.lvl_321Code.GDBush_9595Background_9595ShadowObjects2.length = 0;
gdjs.lvl_321Code.GDGrass_9595backgroundObjects1.length = 0;
gdjs.lvl_321Code.GDGrass_9595backgroundObjects2.length = 0;
gdjs.lvl_321Code.GDBush_9595foregroundObjects1.length = 0;
gdjs.lvl_321Code.GDBush_9595foregroundObjects2.length = 0;
gdjs.lvl_321Code.GDMushroomsObjects1.length = 0;
gdjs.lvl_321Code.GDMushroomsObjects2.length = 0;
gdjs.lvl_321Code.GDGrass_9595foregroundObjects1.length = 0;
gdjs.lvl_321Code.GDGrass_9595foregroundObjects2.length = 0;
gdjs.lvl_321Code.GDTile_95951Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95951Objects2.length = 0;
gdjs.lvl_321Code.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.lvl_321Code.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.lvl_321Code.GDTile_959511Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959511Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959512Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959512Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959514Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959514Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959516Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959516Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959517Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959517Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959513Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959513Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959515Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959515Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959518Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959518Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959519Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959519Objects2.length = 0;
gdjs.lvl_321Code.GDTile_95952Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95952Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959520Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959520Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959521Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959521Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959522Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959522Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959523Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959523Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959524Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959524Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959527Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959527Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959525Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959525Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959528Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959528Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959531Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959531Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959529Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959529Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959532Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959532Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959535Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959535Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959536Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959536Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959537Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959537Objects2.length = 0;
gdjs.lvl_321Code.GDTile_95957Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95957Objects2.length = 0;
gdjs.lvl_321Code.GDTile_95958Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95958Objects2.length = 0;
gdjs.lvl_321Code.GDBatObjects1.length = 0;
gdjs.lvl_321Code.GDBatObjects2.length = 0;
gdjs.lvl_321Code.GDTile_95959Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95959Objects2.length = 0;
gdjs.lvl_321Code.GDDark_9595GuardObjects1.length = 0;
gdjs.lvl_321Code.GDDark_9595GuardObjects2.length = 0;
gdjs.lvl_321Code.GDBoss_9595GolemObjects1.length = 0;
gdjs.lvl_321Code.GDBoss_9595GolemObjects2.length = 0;
gdjs.lvl_321Code.GDForest_9595Goblin_9595HogObjects1.length = 0;
gdjs.lvl_321Code.GDForest_9595Goblin_9595HogObjects2.length = 0;
gdjs.lvl_321Code.GDForest_9595GoblinObjects1.length = 0;
gdjs.lvl_321Code.GDForest_9595GoblinObjects2.length = 0;
gdjs.lvl_321Code.GDFrogObjects1.length = 0;
gdjs.lvl_321Code.GDFrogObjects2.length = 0;
gdjs.lvl_321Code.GDMushroomObjects1.length = 0;
gdjs.lvl_321Code.GDMushroomObjects2.length = 0;
gdjs.lvl_321Code.GDFrog_9595TongueObjects1.length = 0;
gdjs.lvl_321Code.GDFrog_9595TongueObjects2.length = 0;
gdjs.lvl_321Code.GDNecromancerObjects1.length = 0;
gdjs.lvl_321Code.GDNecromancerObjects2.length = 0;
gdjs.lvl_321Code.GDSkull_9595SlimeObjects1.length = 0;
gdjs.lvl_321Code.GDSkull_9595SlimeObjects2.length = 0;
gdjs.lvl_321Code.GDPlant_9595MutantObjects1.length = 0;
gdjs.lvl_321Code.GDPlant_9595MutantObjects2.length = 0;
gdjs.lvl_321Code.GDbarnacleObjects1.length = 0;
gdjs.lvl_321Code.GDbarnacleObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595yellowObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595yellowObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595pinkObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595pinkObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595beigeObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595beigeObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595purpleObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595purpleObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595greenObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595greenObjects2.length = 0;
gdjs.lvl_321Code.GDbeeObjects1.length = 0;
gdjs.lvl_321Code.GDbeeObjects2.length = 0;
gdjs.lvl_321Code.GDfish_9595yellowObjects1.length = 0;
gdjs.lvl_321Code.GDfish_9595yellowObjects2.length = 0;
gdjs.lvl_321Code.GDfish_9595blueObjects1.length = 0;
gdjs.lvl_321Code.GDfish_9595blueObjects2.length = 0;
gdjs.lvl_321Code.GDfish_9595purpleObjects1.length = 0;
gdjs.lvl_321Code.GDfish_9595purpleObjects2.length = 0;
gdjs.lvl_321Code.GDblockObjects1.length = 0;
gdjs.lvl_321Code.GDblockObjects2.length = 0;
gdjs.lvl_321Code.GDflyObjects1.length = 0;
gdjs.lvl_321Code.GDflyObjects2.length = 0;
gdjs.lvl_321Code.GDfrogObjects1.length = 0;
gdjs.lvl_321Code.GDfrogObjects2.length = 0;
gdjs.lvl_321Code.GDsawObjects1.length = 0;
gdjs.lvl_321Code.GDsawObjects2.length = 0;
gdjs.lvl_321Code.GDmouseObjects1.length = 0;
gdjs.lvl_321Code.GDmouseObjects2.length = 0;
gdjs.lvl_321Code.GDladybugObjects1.length = 0;
gdjs.lvl_321Code.GDladybugObjects2.length = 0;
gdjs.lvl_321Code.GDslime_9595blockObjects1.length = 0;
gdjs.lvl_321Code.GDslime_9595blockObjects2.length = 0;
gdjs.lvl_321Code.GDslime_9595fireObjects1.length = 0;
gdjs.lvl_321Code.GDslime_9595fireObjects2.length = 0;
gdjs.lvl_321Code.GDslime_9595spikeObjects1.length = 0;
gdjs.lvl_321Code.GDslime_9595spikeObjects2.length = 0;
gdjs.lvl_321Code.GDslime_9595normalObjects1.length = 0;
gdjs.lvl_321Code.GDslime_9595normalObjects2.length = 0;
gdjs.lvl_321Code.GDsnailObjects1.length = 0;
gdjs.lvl_321Code.GDsnailObjects2.length = 0;
gdjs.lvl_321Code.GDworm_9595ringObjects1.length = 0;
gdjs.lvl_321Code.GDworm_9595ringObjects2.length = 0;
gdjs.lvl_321Code.GDworm_9595normalObjects1.length = 0;
gdjs.lvl_321Code.GDworm_9595normalObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595characterObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595characterObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595coinObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595coinObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595keyObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595keyObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595player_9595helmetObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595player_9595helmetObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595coinObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595coinObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595heartObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595heartObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595exclamationObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595exclamationObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595planksObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595planksObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595coinObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595coinObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595playerObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595playerObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595dangerObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595dangerObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595emptyObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595emptyObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595exclamationObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595exclamationObjects2.length = 0;
gdjs.lvl_321Code.GDblock2Objects1.length = 0;
gdjs.lvl_321Code.GDblock2Objects2.length = 0;
gdjs.lvl_321Code.GDbombObjects1.length = 0;
gdjs.lvl_321Code.GDbombObjects2.length = 0;
gdjs.lvl_321Code.GDbridgeObjects1.length = 0;
gdjs.lvl_321Code.GDbridgeObjects2.length = 0;
gdjs.lvl_321Code.GDbricksObjects1.length = 0;
gdjs.lvl_321Code.GDbricksObjects2.length = 0;
gdjs.lvl_321Code.GDcactusObjects1.length = 0;
gdjs.lvl_321Code.GDcactusObjects2.length = 0;
gdjs.lvl_321Code.GDcoin_9595goldObjects1.length = 0;
gdjs.lvl_321Code.GDcoin_9595goldObjects2.length = 0;
gdjs.lvl_321Code.GDcoin_9595bronzeObjects1.length = 0;
gdjs.lvl_321Code.GDcoin_9595bronzeObjects2.length = 0;
gdjs.lvl_321Code.GDbushObjects1.length = 0;
gdjs.lvl_321Code.GDbushObjects2.length = 0;
gdjs.lvl_321Code.GDconveyorObjects1.length = 0;
gdjs.lvl_321Code.GDconveyorObjects2.length = 0;
gdjs.lvl_321Code.GDcoin_9595silverObjects1.length = 0;
gdjs.lvl_321Code.GDcoin_9595silverObjects2.length = 0;
gdjs.lvl_321Code.GDdoor_9595topObjects1.length = 0;
gdjs.lvl_321Code.GDdoor_9595topObjects2.length = 0;
gdjs.lvl_321Code.GDfenceObjects1.length = 0;
gdjs.lvl_321Code.GDfenceObjects2.length = 0;
gdjs.lvl_321Code.GDfireballObjects1.length = 0;
gdjs.lvl_321Code.GDfireballObjects2.length = 0;
gdjs.lvl_321Code.GDflagObjects1.length = 0;
gdjs.lvl_321Code.GDflagObjects2.length = 0;
gdjs.lvl_321Code.GDgemObjects1.length = 0;
gdjs.lvl_321Code.GDgemObjects2.length = 0;
gdjs.lvl_321Code.GDheartObjects1.length = 0;
gdjs.lvl_321Code.GDheartObjects2.length = 0;
gdjs.lvl_321Code.GDgrassObjects1.length = 0;
gdjs.lvl_321Code.GDgrassObjects2.length = 0;
gdjs.lvl_321Code.GDhillObjects1.length = 0;
gdjs.lvl_321Code.GDhillObjects2.length = 0;
gdjs.lvl_321Code.GDkeyObjects1.length = 0;
gdjs.lvl_321Code.GDkeyObjects2.length = 0;
gdjs.lvl_321Code.GDlavaObjects1.length = 0;
gdjs.lvl_321Code.GDlavaObjects2.length = 0;
gdjs.lvl_321Code.GDleverObjects1.length = 0;
gdjs.lvl_321Code.GDleverObjects2.length = 0;
gdjs.lvl_321Code.GDdoor_9595longObjects1.length = 0;
gdjs.lvl_321Code.GDdoor_9595longObjects2.length = 0;
gdjs.lvl_321Code.GDmushroomObjects1.length = 0;
gdjs.lvl_321Code.GDmushroomObjects2.length = 0;
gdjs.lvl_321Code.GDlockObjects1.length = 0;
gdjs.lvl_321Code.GDlockObjects2.length = 0;
gdjs.lvl_321Code.GDkillboxObjects1.length = 0;
gdjs.lvl_321Code.GDkillboxObjects2.length = 0;
gdjs.lvl_321Code.GDexplosionObjects1.length = 0;
gdjs.lvl_321Code.GDexplosionObjects2.length = 0;
gdjs.lvl_321Code.GDwaypoint_95951_9595Objects1.length = 0;
gdjs.lvl_321Code.GDwaypoint_95951_9595Objects2.length = 0;
gdjs.lvl_321Code.GDAngela_9595DemonObjects1.length = 0;
gdjs.lvl_321Code.GDAngela_9595DemonObjects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95951Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95951Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95952Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95952Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95953Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95953Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95951Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95951Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95952Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95952Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95953Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95953Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95954Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95954Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95955Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95955Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95956Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95956Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95957Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95957Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95958Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95958Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95951Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95951Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95952Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95952Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95954Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95954Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95953Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95953Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95955Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95955Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95956Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95956Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95957Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95957Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95958Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95958Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95952Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95952Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95951Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95951Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95953Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95953Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95954Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95954Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95955Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95955Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95956Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95956Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95957Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95957Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959510Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959510Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95958Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95958Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95954Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95954Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95955Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95955Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95956Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95956Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95957Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95957Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95958Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95958Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95959Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95959Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959511Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959511Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959512Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959512Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959513Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959513Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95951Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95951Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95952Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95952Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95953Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95953Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95954Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95954Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95955Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95955Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95956Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95956Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95957Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95957Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95958Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95958Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95951Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95951Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95952Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95952Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95954Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95954Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95953Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95953Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95955Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95955Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95956Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95956Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95957Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95957Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95958Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95958Objects2.length = 0;

gdjs.lvl_321Code.eventsList0(runtimeScene);
gdjs.lvl_321Code.GDHouse_9595tall_9595backgroundObjects1.length = 0;
gdjs.lvl_321Code.GDHouse_9595tall_9595backgroundObjects2.length = 0;
gdjs.lvl_321Code.GDHouse_9595tall_9595foregroundObjects1.length = 0;
gdjs.lvl_321Code.GDHouse_9595tall_9595foregroundObjects2.length = 0;
gdjs.lvl_321Code.GDHouseObjects1.length = 0;
gdjs.lvl_321Code.GDHouseObjects2.length = 0;
gdjs.lvl_321Code.GDMerged_9595Full_9595BackgroundObjects1.length = 0;
gdjs.lvl_321Code.GDMerged_9595Full_9595BackgroundObjects2.length = 0;
gdjs.lvl_321Code.GDHouse_9595small_9595backgroundObjects1.length = 0;
gdjs.lvl_321Code.GDHouse_9595small_9595backgroundObjects2.length = 0;
gdjs.lvl_321Code.GDBridge_9595HandleObjects1.length = 0;
gdjs.lvl_321Code.GDBridge_9595HandleObjects2.length = 0;
gdjs.lvl_321Code.GDBridge_9595SupportObjects1.length = 0;
gdjs.lvl_321Code.GDBridge_9595SupportObjects2.length = 0;
gdjs.lvl_321Code.GDBridgeObjects1.length = 0;
gdjs.lvl_321Code.GDBridgeObjects2.length = 0;
gdjs.lvl_321Code.GDCave_9595Background_9595HoleObjects1.length = 0;
gdjs.lvl_321Code.GDCave_9595Background_9595HoleObjects2.length = 0;
gdjs.lvl_321Code.GDCave_9595BackgroundObjects1.length = 0;
gdjs.lvl_321Code.GDCave_9595BackgroundObjects2.length = 0;
gdjs.lvl_321Code.GDCave_9595EntranceObjects1.length = 0;
gdjs.lvl_321Code.GDCave_9595EntranceObjects2.length = 0;
gdjs.lvl_321Code.GDLamp_9595leftObjects1.length = 0;
gdjs.lvl_321Code.GDLamp_9595leftObjects2.length = 0;
gdjs.lvl_321Code.GDLamp_9595rightObjects1.length = 0;
gdjs.lvl_321Code.GDLamp_9595rightObjects2.length = 0;
gdjs.lvl_321Code.GDBush_9595BackgroundObjects1.length = 0;
gdjs.lvl_321Code.GDBush_9595BackgroundObjects2.length = 0;
gdjs.lvl_321Code.GDBush_9595Background_9595ShadowObjects1.length = 0;
gdjs.lvl_321Code.GDBush_9595Background_9595ShadowObjects2.length = 0;
gdjs.lvl_321Code.GDGrass_9595backgroundObjects1.length = 0;
gdjs.lvl_321Code.GDGrass_9595backgroundObjects2.length = 0;
gdjs.lvl_321Code.GDBush_9595foregroundObjects1.length = 0;
gdjs.lvl_321Code.GDBush_9595foregroundObjects2.length = 0;
gdjs.lvl_321Code.GDMushroomsObjects1.length = 0;
gdjs.lvl_321Code.GDMushroomsObjects2.length = 0;
gdjs.lvl_321Code.GDGrass_9595foregroundObjects1.length = 0;
gdjs.lvl_321Code.GDGrass_9595foregroundObjects2.length = 0;
gdjs.lvl_321Code.GDTile_95951Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95951Objects2.length = 0;
gdjs.lvl_321Code.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.lvl_321Code.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.lvl_321Code.GDTile_959511Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959511Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959512Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959512Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959514Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959514Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959516Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959516Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959517Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959517Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959513Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959513Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959515Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959515Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959518Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959518Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959519Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959519Objects2.length = 0;
gdjs.lvl_321Code.GDTile_95952Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95952Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959520Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959520Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959521Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959521Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959522Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959522Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959523Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959523Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959524Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959524Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959527Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959527Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959525Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959525Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959528Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959528Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959531Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959531Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959529Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959529Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959532Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959532Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959535Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959535Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959536Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959536Objects2.length = 0;
gdjs.lvl_321Code.GDTile_959537Objects1.length = 0;
gdjs.lvl_321Code.GDTile_959537Objects2.length = 0;
gdjs.lvl_321Code.GDTile_95957Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95957Objects2.length = 0;
gdjs.lvl_321Code.GDTile_95958Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95958Objects2.length = 0;
gdjs.lvl_321Code.GDBatObjects1.length = 0;
gdjs.lvl_321Code.GDBatObjects2.length = 0;
gdjs.lvl_321Code.GDTile_95959Objects1.length = 0;
gdjs.lvl_321Code.GDTile_95959Objects2.length = 0;
gdjs.lvl_321Code.GDDark_9595GuardObjects1.length = 0;
gdjs.lvl_321Code.GDDark_9595GuardObjects2.length = 0;
gdjs.lvl_321Code.GDBoss_9595GolemObjects1.length = 0;
gdjs.lvl_321Code.GDBoss_9595GolemObjects2.length = 0;
gdjs.lvl_321Code.GDForest_9595Goblin_9595HogObjects1.length = 0;
gdjs.lvl_321Code.GDForest_9595Goblin_9595HogObjects2.length = 0;
gdjs.lvl_321Code.GDForest_9595GoblinObjects1.length = 0;
gdjs.lvl_321Code.GDForest_9595GoblinObjects2.length = 0;
gdjs.lvl_321Code.GDFrogObjects1.length = 0;
gdjs.lvl_321Code.GDFrogObjects2.length = 0;
gdjs.lvl_321Code.GDMushroomObjects1.length = 0;
gdjs.lvl_321Code.GDMushroomObjects2.length = 0;
gdjs.lvl_321Code.GDFrog_9595TongueObjects1.length = 0;
gdjs.lvl_321Code.GDFrog_9595TongueObjects2.length = 0;
gdjs.lvl_321Code.GDNecromancerObjects1.length = 0;
gdjs.lvl_321Code.GDNecromancerObjects2.length = 0;
gdjs.lvl_321Code.GDSkull_9595SlimeObjects1.length = 0;
gdjs.lvl_321Code.GDSkull_9595SlimeObjects2.length = 0;
gdjs.lvl_321Code.GDPlant_9595MutantObjects1.length = 0;
gdjs.lvl_321Code.GDPlant_9595MutantObjects2.length = 0;
gdjs.lvl_321Code.GDbarnacleObjects1.length = 0;
gdjs.lvl_321Code.GDbarnacleObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595yellowObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595yellowObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595pinkObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595pinkObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595beigeObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595beigeObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595purpleObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595purpleObjects2.length = 0;
gdjs.lvl_321Code.GDcharacter_9595greenObjects1.length = 0;
gdjs.lvl_321Code.GDcharacter_9595greenObjects2.length = 0;
gdjs.lvl_321Code.GDbeeObjects1.length = 0;
gdjs.lvl_321Code.GDbeeObjects2.length = 0;
gdjs.lvl_321Code.GDfish_9595yellowObjects1.length = 0;
gdjs.lvl_321Code.GDfish_9595yellowObjects2.length = 0;
gdjs.lvl_321Code.GDfish_9595blueObjects1.length = 0;
gdjs.lvl_321Code.GDfish_9595blueObjects2.length = 0;
gdjs.lvl_321Code.GDfish_9595purpleObjects1.length = 0;
gdjs.lvl_321Code.GDfish_9595purpleObjects2.length = 0;
gdjs.lvl_321Code.GDblockObjects1.length = 0;
gdjs.lvl_321Code.GDblockObjects2.length = 0;
gdjs.lvl_321Code.GDflyObjects1.length = 0;
gdjs.lvl_321Code.GDflyObjects2.length = 0;
gdjs.lvl_321Code.GDfrogObjects1.length = 0;
gdjs.lvl_321Code.GDfrogObjects2.length = 0;
gdjs.lvl_321Code.GDsawObjects1.length = 0;
gdjs.lvl_321Code.GDsawObjects2.length = 0;
gdjs.lvl_321Code.GDmouseObjects1.length = 0;
gdjs.lvl_321Code.GDmouseObjects2.length = 0;
gdjs.lvl_321Code.GDladybugObjects1.length = 0;
gdjs.lvl_321Code.GDladybugObjects2.length = 0;
gdjs.lvl_321Code.GDslime_9595blockObjects1.length = 0;
gdjs.lvl_321Code.GDslime_9595blockObjects2.length = 0;
gdjs.lvl_321Code.GDslime_9595fireObjects1.length = 0;
gdjs.lvl_321Code.GDslime_9595fireObjects2.length = 0;
gdjs.lvl_321Code.GDslime_9595spikeObjects1.length = 0;
gdjs.lvl_321Code.GDslime_9595spikeObjects2.length = 0;
gdjs.lvl_321Code.GDslime_9595normalObjects1.length = 0;
gdjs.lvl_321Code.GDslime_9595normalObjects2.length = 0;
gdjs.lvl_321Code.GDsnailObjects1.length = 0;
gdjs.lvl_321Code.GDsnailObjects2.length = 0;
gdjs.lvl_321Code.GDworm_9595ringObjects1.length = 0;
gdjs.lvl_321Code.GDworm_9595ringObjects2.length = 0;
gdjs.lvl_321Code.GDworm_9595normalObjects1.length = 0;
gdjs.lvl_321Code.GDworm_9595normalObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595characterObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595characterObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595coinObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595coinObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595keyObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595keyObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595player_9595helmetObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595player_9595helmetObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595coinObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595coinObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595heartObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595heartObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595exclamationObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595exclamationObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595planksObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595planksObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595coinObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595coinObjects2.length = 0;
gdjs.lvl_321Code.GDhud_9595playerObjects1.length = 0;
gdjs.lvl_321Code.GDhud_9595playerObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595dangerObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595dangerObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595emptyObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595emptyObjects2.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595exclamationObjects1.length = 0;
gdjs.lvl_321Code.GDblock_9595strong_9595exclamationObjects2.length = 0;
gdjs.lvl_321Code.GDblock2Objects1.length = 0;
gdjs.lvl_321Code.GDblock2Objects2.length = 0;
gdjs.lvl_321Code.GDbombObjects1.length = 0;
gdjs.lvl_321Code.GDbombObjects2.length = 0;
gdjs.lvl_321Code.GDbridgeObjects1.length = 0;
gdjs.lvl_321Code.GDbridgeObjects2.length = 0;
gdjs.lvl_321Code.GDbricksObjects1.length = 0;
gdjs.lvl_321Code.GDbricksObjects2.length = 0;
gdjs.lvl_321Code.GDcactusObjects1.length = 0;
gdjs.lvl_321Code.GDcactusObjects2.length = 0;
gdjs.lvl_321Code.GDcoin_9595goldObjects1.length = 0;
gdjs.lvl_321Code.GDcoin_9595goldObjects2.length = 0;
gdjs.lvl_321Code.GDcoin_9595bronzeObjects1.length = 0;
gdjs.lvl_321Code.GDcoin_9595bronzeObjects2.length = 0;
gdjs.lvl_321Code.GDbushObjects1.length = 0;
gdjs.lvl_321Code.GDbushObjects2.length = 0;
gdjs.lvl_321Code.GDconveyorObjects1.length = 0;
gdjs.lvl_321Code.GDconveyorObjects2.length = 0;
gdjs.lvl_321Code.GDcoin_9595silverObjects1.length = 0;
gdjs.lvl_321Code.GDcoin_9595silverObjects2.length = 0;
gdjs.lvl_321Code.GDdoor_9595topObjects1.length = 0;
gdjs.lvl_321Code.GDdoor_9595topObjects2.length = 0;
gdjs.lvl_321Code.GDfenceObjects1.length = 0;
gdjs.lvl_321Code.GDfenceObjects2.length = 0;
gdjs.lvl_321Code.GDfireballObjects1.length = 0;
gdjs.lvl_321Code.GDfireballObjects2.length = 0;
gdjs.lvl_321Code.GDflagObjects1.length = 0;
gdjs.lvl_321Code.GDflagObjects2.length = 0;
gdjs.lvl_321Code.GDgemObjects1.length = 0;
gdjs.lvl_321Code.GDgemObjects2.length = 0;
gdjs.lvl_321Code.GDheartObjects1.length = 0;
gdjs.lvl_321Code.GDheartObjects2.length = 0;
gdjs.lvl_321Code.GDgrassObjects1.length = 0;
gdjs.lvl_321Code.GDgrassObjects2.length = 0;
gdjs.lvl_321Code.GDhillObjects1.length = 0;
gdjs.lvl_321Code.GDhillObjects2.length = 0;
gdjs.lvl_321Code.GDkeyObjects1.length = 0;
gdjs.lvl_321Code.GDkeyObjects2.length = 0;
gdjs.lvl_321Code.GDlavaObjects1.length = 0;
gdjs.lvl_321Code.GDlavaObjects2.length = 0;
gdjs.lvl_321Code.GDleverObjects1.length = 0;
gdjs.lvl_321Code.GDleverObjects2.length = 0;
gdjs.lvl_321Code.GDdoor_9595longObjects1.length = 0;
gdjs.lvl_321Code.GDdoor_9595longObjects2.length = 0;
gdjs.lvl_321Code.GDmushroomObjects1.length = 0;
gdjs.lvl_321Code.GDmushroomObjects2.length = 0;
gdjs.lvl_321Code.GDlockObjects1.length = 0;
gdjs.lvl_321Code.GDlockObjects2.length = 0;
gdjs.lvl_321Code.GDkillboxObjects1.length = 0;
gdjs.lvl_321Code.GDkillboxObjects2.length = 0;
gdjs.lvl_321Code.GDexplosionObjects1.length = 0;
gdjs.lvl_321Code.GDexplosionObjects2.length = 0;
gdjs.lvl_321Code.GDwaypoint_95951_9595Objects1.length = 0;
gdjs.lvl_321Code.GDwaypoint_95951_9595Objects2.length = 0;
gdjs.lvl_321Code.GDAngela_9595DemonObjects1.length = 0;
gdjs.lvl_321Code.GDAngela_9595DemonObjects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95951Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95951Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95952Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95952Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95953Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95953Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95951Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95951Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95952Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95952Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95953Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95953Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95954Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95954Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95955Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95955Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95956Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95956Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95957Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95957Objects2.length = 0;
gdjs.lvl_321Code.GDBard_95958Objects1.length = 0;
gdjs.lvl_321Code.GDBard_95958Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95951Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95951Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95952Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95952Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95954Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95954Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95953Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95953Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95955Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95955Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95956Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95956Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95957Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95957Objects2.length = 0;
gdjs.lvl_321Code.GDConjurer_95958Objects1.length = 0;
gdjs.lvl_321Code.GDConjurer_95958Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95952Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95952Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95951Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95951Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95953Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95953Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95954Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95954Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95955Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95955Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95956Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95956Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95957Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95957Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959510Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959510Objects2.length = 0;
gdjs.lvl_321Code.GDDevout_95958Objects1.length = 0;
gdjs.lvl_321Code.GDDevout_95958Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95954Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95954Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95955Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95955Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95956Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95956Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95957Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95957Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95958Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95958Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95959Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_95959Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959511Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959511Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959512Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959512Objects2.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959513Objects1.length = 0;
gdjs.lvl_321Code.GDGeneric_9595Character_959513Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95951Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95951Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95952Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95952Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95953Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95953Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95954Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95954Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95955Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95955Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95956Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95956Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95957Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95957Objects2.length = 0;
gdjs.lvl_321Code.GDScout_95958Objects1.length = 0;
gdjs.lvl_321Code.GDScout_95958Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95951Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95951Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95952Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95952Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95954Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95954Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95953Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95953Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95955Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95955Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95956Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95956Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95957Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95957Objects2.length = 0;
gdjs.lvl_321Code.GDSoldier_95958Objects1.length = 0;
gdjs.lvl_321Code.GDSoldier_95958Objects2.length = 0;


return;

}

gdjs['lvl_321Code'] = gdjs.lvl_321Code;
