gdjs.lvl_322Code = {};
gdjs.lvl_322Code.localVariables = [];
gdjs.lvl_322Code.idToCallbackMap = new Map();
gdjs.lvl_322Code.GDcloud_95952Objects1= [];
gdjs.lvl_322Code.GDcloud_95952Objects2= [];
gdjs.lvl_322Code.GDcloud_95954Objects1= [];
gdjs.lvl_322Code.GDcloud_95954Objects2= [];
gdjs.lvl_322Code.GDcloud_95951Objects1= [];
gdjs.lvl_322Code.GDcloud_95951Objects2= [];
gdjs.lvl_322Code.GDcloud_95953Objects1= [];
gdjs.lvl_322Code.GDcloud_95953Objects2= [];
gdjs.lvl_322Code.GDcloud_95955Objects1= [];
gdjs.lvl_322Code.GDcloud_95955Objects2= [];
gdjs.lvl_322Code.GDcloud_95956Objects1= [];
gdjs.lvl_322Code.GDcloud_95956Objects2= [];
gdjs.lvl_322Code.GDcloud_95957Objects1= [];
gdjs.lvl_322Code.GDcloud_95957Objects2= [];
gdjs.lvl_322Code.GDcloud_95958Objects1= [];
gdjs.lvl_322Code.GDcloud_95958Objects2= [];
gdjs.lvl_322Code.GDCastles_9595BackgroundObjects1= [];
gdjs.lvl_322Code.GDCastles_9595BackgroundObjects2= [];
gdjs.lvl_322Code.GDmoonObjects1= [];
gdjs.lvl_322Code.GDmoonObjects2= [];
gdjs.lvl_322Code.GDfenceObjects1= [];
gdjs.lvl_322Code.GDfenceObjects2= [];
gdjs.lvl_322Code.GDDesert_9595Background_95952Objects1= [];
gdjs.lvl_322Code.GDDesert_9595Background_95952Objects2= [];
gdjs.lvl_322Code.GDEmpty_9595Cloud_9595BackgroundObjects1= [];
gdjs.lvl_322Code.GDEmpty_9595Cloud_9595BackgroundObjects2= [];
gdjs.lvl_322Code.GDForest_9595BackgroundObjects1= [];
gdjs.lvl_322Code.GDForest_9595BackgroundObjects2= [];
gdjs.lvl_322Code.GDFall_9595Trees_9595BackgroundObjects1= [];
gdjs.lvl_322Code.GDFall_9595Trees_9595BackgroundObjects2= [];
gdjs.lvl_322Code.GDDesert_9595BackgroundObjects1= [];
gdjs.lvl_322Code.GDDesert_9595BackgroundObjects2= [];
gdjs.lvl_322Code.GDForest_9595Background_95952Objects1= [];
gdjs.lvl_322Code.GDForest_9595Background_95952Objects2= [];
gdjs.lvl_322Code.GDGrass_9595and_9595Tree_9595BackgroundObjects1= [];
gdjs.lvl_322Code.GDGrass_9595and_9595Tree_9595BackgroundObjects2= [];
gdjs.lvl_322Code.GDCloud_9595layer_95952Objects1= [];
gdjs.lvl_322Code.GDCloud_9595layer_95952Objects2= [];
gdjs.lvl_322Code.GDBackground_9595MountainsObjects1= [];
gdjs.lvl_322Code.GDBackground_9595MountainsObjects2= [];
gdjs.lvl_322Code.GDCloud_9595layer_95953Objects1= [];
gdjs.lvl_322Code.GDCloud_9595layer_95953Objects2= [];
gdjs.lvl_322Code.GDCloud_9595layer_95951Objects1= [];
gdjs.lvl_322Code.GDCloud_9595layer_95951Objects2= [];
gdjs.lvl_322Code.GDCloud_9595layer_95954Objects1= [];
gdjs.lvl_322Code.GDCloud_9595layer_95954Objects2= [];
gdjs.lvl_322Code.GDGround_9595Layer_95951Objects1= [];
gdjs.lvl_322Code.GDGround_9595Layer_95951Objects2= [];
gdjs.lvl_322Code.GDLarge_9595hillsObjects1= [];
gdjs.lvl_322Code.GDLarge_9595hillsObjects2= [];
gdjs.lvl_322Code.GDAlternative_9595castle_9595wallObjects1= [];
gdjs.lvl_322Code.GDAlternative_9595castle_9595wallObjects2= [];
gdjs.lvl_322Code.GDGround_9595Layer_95952Objects1= [];
gdjs.lvl_322Code.GDGround_9595Layer_95952Objects2= [];
gdjs.lvl_322Code.GDHillsObjects1= [];
gdjs.lvl_322Code.GDHillsObjects2= [];
gdjs.lvl_322Code.GDCastle_9595WallObjects1= [];
gdjs.lvl_322Code.GDCastle_9595WallObjects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95953Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95953Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95951Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95951Objects2= [];
gdjs.lvl_322Code.GDBard_95952Objects1= [];
gdjs.lvl_322Code.GDBard_95952Objects2= [];
gdjs.lvl_322Code.GDBard_95953Objects1= [];
gdjs.lvl_322Code.GDBard_95953Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95952Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95952Objects2= [];
gdjs.lvl_322Code.GDBard_95951Objects1= [];
gdjs.lvl_322Code.GDBard_95951Objects2= [];
gdjs.lvl_322Code.GDBard_95954Objects1= [];
gdjs.lvl_322Code.GDBard_95954Objects2= [];
gdjs.lvl_322Code.GDBard_95955Objects1= [];
gdjs.lvl_322Code.GDBard_95955Objects2= [];
gdjs.lvl_322Code.GDBard_95957Objects1= [];
gdjs.lvl_322Code.GDBard_95957Objects2= [];
gdjs.lvl_322Code.GDBard_95956Objects1= [];
gdjs.lvl_322Code.GDBard_95956Objects2= [];
gdjs.lvl_322Code.GDBard_95958Objects1= [];
gdjs.lvl_322Code.GDBard_95958Objects2= [];
gdjs.lvl_322Code.GDConjurer_95951Objects1= [];
gdjs.lvl_322Code.GDConjurer_95951Objects2= [];
gdjs.lvl_322Code.GDConjurer_95955Objects1= [];
gdjs.lvl_322Code.GDConjurer_95955Objects2= [];
gdjs.lvl_322Code.GDConjurer_95952Objects1= [];
gdjs.lvl_322Code.GDConjurer_95952Objects2= [];
gdjs.lvl_322Code.GDConjurer_95953Objects1= [];
gdjs.lvl_322Code.GDConjurer_95953Objects2= [];
gdjs.lvl_322Code.GDConjurer_95954Objects1= [];
gdjs.lvl_322Code.GDConjurer_95954Objects2= [];
gdjs.lvl_322Code.GDConjurer_95956Objects1= [];
gdjs.lvl_322Code.GDConjurer_95956Objects2= [];
gdjs.lvl_322Code.GDConjurer_95957Objects1= [];
gdjs.lvl_322Code.GDConjurer_95957Objects2= [];
gdjs.lvl_322Code.GDDevout_95951Objects1= [];
gdjs.lvl_322Code.GDDevout_95951Objects2= [];
gdjs.lvl_322Code.GDConjurer_95958Objects1= [];
gdjs.lvl_322Code.GDConjurer_95958Objects2= [];
gdjs.lvl_322Code.GDDevout_95952Objects1= [];
gdjs.lvl_322Code.GDDevout_95952Objects2= [];
gdjs.lvl_322Code.GDDevout_95953Objects1= [];
gdjs.lvl_322Code.GDDevout_95953Objects2= [];
gdjs.lvl_322Code.GDDevout_95954Objects1= [];
gdjs.lvl_322Code.GDDevout_95954Objects2= [];
gdjs.lvl_322Code.GDDevout_95955Objects1= [];
gdjs.lvl_322Code.GDDevout_95955Objects2= [];
gdjs.lvl_322Code.GDDevout_95957Objects1= [];
gdjs.lvl_322Code.GDDevout_95957Objects2= [];
gdjs.lvl_322Code.GDDevout_95956Objects1= [];
gdjs.lvl_322Code.GDDevout_95956Objects2= [];
gdjs.lvl_322Code.GDDevout_95958Objects1= [];
gdjs.lvl_322Code.GDDevout_95958Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_959510Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_959510Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95954Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95954Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95955Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95955Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95956Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95956Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95957Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95957Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95958Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95958Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95959Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_95959Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_959511Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_959511Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_959512Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_959512Objects2= [];
gdjs.lvl_322Code.GDScout_95953Objects1= [];
gdjs.lvl_322Code.GDScout_95953Objects2= [];
gdjs.lvl_322Code.GDScout_95951Objects1= [];
gdjs.lvl_322Code.GDScout_95951Objects2= [];
gdjs.lvl_322Code.GDGeneric_9595Character_959513Objects1= [];
gdjs.lvl_322Code.GDGeneric_9595Character_959513Objects2= [];
gdjs.lvl_322Code.GDScout_95952Objects1= [];
gdjs.lvl_322Code.GDScout_95952Objects2= [];
gdjs.lvl_322Code.GDScout_95954Objects1= [];
gdjs.lvl_322Code.GDScout_95954Objects2= [];
gdjs.lvl_322Code.GDScout_95955Objects1= [];
gdjs.lvl_322Code.GDScout_95955Objects2= [];
gdjs.lvl_322Code.GDScout_95956Objects1= [];
gdjs.lvl_322Code.GDScout_95956Objects2= [];
gdjs.lvl_322Code.GDSoldier_95951Objects1= [];
gdjs.lvl_322Code.GDSoldier_95951Objects2= [];
gdjs.lvl_322Code.GDScout_95957Objects1= [];
gdjs.lvl_322Code.GDScout_95957Objects2= [];
gdjs.lvl_322Code.GDScout_95958Objects1= [];
gdjs.lvl_322Code.GDScout_95958Objects2= [];
gdjs.lvl_322Code.GDSoldier_95952Objects1= [];
gdjs.lvl_322Code.GDSoldier_95952Objects2= [];
gdjs.lvl_322Code.GDSoldier_95953Objects1= [];
gdjs.lvl_322Code.GDSoldier_95953Objects2= [];
gdjs.lvl_322Code.GDSoldier_95955Objects1= [];
gdjs.lvl_322Code.GDSoldier_95955Objects2= [];
gdjs.lvl_322Code.GDSoldier_95956Objects1= [];
gdjs.lvl_322Code.GDSoldier_95956Objects2= [];
gdjs.lvl_322Code.GDSoldier_95954Objects1= [];
gdjs.lvl_322Code.GDSoldier_95954Objects2= [];
gdjs.lvl_322Code.GDSoldier_95957Objects1= [];
gdjs.lvl_322Code.GDSoldier_95957Objects2= [];
gdjs.lvl_322Code.GDSoldier_95958Objects1= [];
gdjs.lvl_322Code.GDSoldier_95958Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95956Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95956Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959560Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959560Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959552Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959552Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959559Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959559Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959558Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959558Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959557Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959557Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959561Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959561Objects2= [];
gdjs.lvl_322Code.GDBarrierObjects1= [];
gdjs.lvl_322Code.GDBarrierObjects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95957Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95957Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95958Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95958Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959563Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959563Objects2= [];
gdjs.lvl_322Code.GDElectric_9595TurretObjects1= [];
gdjs.lvl_322Code.GDElectric_9595TurretObjects2= [];
gdjs.lvl_322Code.GDLaser_9595SpikesObjects1= [];
gdjs.lvl_322Code.GDLaser_9595SpikesObjects2= [];
gdjs.lvl_322Code.GDLaser_9595TurretObjects1= [];
gdjs.lvl_322Code.GDLaser_9595TurretObjects2= [];
gdjs.lvl_322Code.GDSawObjects1= [];
gdjs.lvl_322Code.GDSawObjects2= [];
gdjs.lvl_322Code.GDWallObjects1= [];
gdjs.lvl_322Code.GDWallObjects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959512Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959512Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959517Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959517Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959513Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959513Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959510Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959510Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959519Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959519Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95952Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95952Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959520Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959520Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959526Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959526Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959527Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959527Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95953Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95953Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959548Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959548Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959542Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959542Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959550Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959550Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959553Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959553Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959554Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959554Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959555Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959555Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959556Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959556Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959562Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_959562Objects2= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95959Objects1= [];
gdjs.lvl_322Code.GDTileset_9595Piece_95959Objects2= [];
gdjs.lvl_322Code.GDGunObjects1= [];
gdjs.lvl_322Code.GDGunObjects2= [];
gdjs.lvl_322Code.GDBullet_95955Objects1= [];
gdjs.lvl_322Code.GDBullet_95955Objects2= [];
gdjs.lvl_322Code.GDBlood_9595SpotObjects1= [];
gdjs.lvl_322Code.GDBlood_9595SpotObjects2= [];
gdjs.lvl_322Code.GDBlue_9595buttonObjects1= [];
gdjs.lvl_322Code.GDBlue_9595buttonObjects2= [];
gdjs.lvl_322Code.GDMecha_9595BossObjects1= [];
gdjs.lvl_322Code.GDMecha_9595BossObjects2= [];
gdjs.lvl_322Code.GDBullet_95951Objects1= [];
gdjs.lvl_322Code.GDBullet_95951Objects2= [];
gdjs.lvl_322Code.GDBulletObjects1= [];
gdjs.lvl_322Code.GDBulletObjects2= [];
gdjs.lvl_322Code.GDBlueFlameObjects1= [];
gdjs.lvl_322Code.GDBlueFlameObjects2= [];
gdjs.lvl_322Code.GDWall_9595for_9595Blue_9595FloorObjects1= [];
gdjs.lvl_322Code.GDWall_9595for_9595Blue_9595FloorObjects2= [];
gdjs.lvl_322Code.GDMissileObjects1= [];
gdjs.lvl_322Code.GDMissileObjects2= [];
gdjs.lvl_322Code.GDRock_95955Objects1= [];
gdjs.lvl_322Code.GDRock_95955Objects2= [];
gdjs.lvl_322Code.GDRedExplosionObjects1= [];
gdjs.lvl_322Code.GDRedExplosionObjects2= [];
gdjs.lvl_322Code.GDBoss_9595GolemObjects1= [];
gdjs.lvl_322Code.GDBoss_9595GolemObjects2= [];
gdjs.lvl_322Code.GDSmall_9595CastleObjects1= [];
gdjs.lvl_322Code.GDSmall_9595CastleObjects2= [];


gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDLaser_95959595SpikesObjects1Objects = Hashtable.newFrom({"Laser_Spikes": gdjs.lvl_322Code.GDLaser_9595SpikesObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlood_95959595SpotObjects1Objects = Hashtable.newFrom({"Blood_Spot": gdjs.lvl_322Code.GDBlood_9595SpotObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDSawObjects1Objects = Hashtable.newFrom({"Saw": gdjs.lvl_322Code.GDSawObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBarrierObjects1Objects = Hashtable.newFrom({"Barrier": gdjs.lvl_322Code.GDBarrierObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDLaser_95959595SpikesObjects1Objects = Hashtable.newFrom({"Laser_Spikes": gdjs.lvl_322Code.GDLaser_9595SpikesObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_959595957Objects1Objects = Hashtable.newFrom({"Tileset_Piece_7": gdjs.lvl_322Code.GDTileset_9595Piece_95957Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlue_95959595buttonObjects1Objects = Hashtable.newFrom({"Blue_button": gdjs.lvl_322Code.GDBlue_9595buttonObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_959595956Objects1Objects = Hashtable.newFrom({"Tileset_Piece_6": gdjs.lvl_322Code.GDTileset_9595Piece_95956Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDMecha_95959595BossObjects1Objects = Hashtable.newFrom({"Mecha_Boss": gdjs.lvl_322Code.GDMecha_9595BossObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects = Hashtable.newFrom({"Tileset_Piece_33": gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_959595952Objects1Objects = Hashtable.newFrom({"Tileset_Piece_2": gdjs.lvl_322Code.GDTileset_9595Piece_95952Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects = Hashtable.newFrom({"Bullet_5": gdjs.lvl_322Code.GDBullet_95955Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595951Objects1Objects = Hashtable.newFrom({"Bullet_1": gdjs.lvl_322Code.GDBullet_95951Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects = Hashtable.newFrom({"Bullet_5": gdjs.lvl_322Code.GDBullet_95955Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects = Hashtable.newFrom({"Bullet_5": gdjs.lvl_322Code.GDBullet_95955Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.lvl_322Code.GDWallObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects = Hashtable.newFrom({"Bullet_5": gdjs.lvl_322Code.GDBullet_95955Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects = Hashtable.newFrom({"Tileset_Piece_33": gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects = Hashtable.newFrom({"Bullet_5": gdjs.lvl_322Code.GDBullet_95955Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBarrierObjects1Objects = Hashtable.newFrom({"Barrier": gdjs.lvl_322Code.GDBarrierObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects = Hashtable.newFrom({"Bullet_5": gdjs.lvl_322Code.GDBullet_95955Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595951Objects1Objects = Hashtable.newFrom({"Bullet_1": gdjs.lvl_322Code.GDBullet_95951Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects = Hashtable.newFrom({"Tileset_Piece_33": gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects = Hashtable.newFrom({"Bullet_5": gdjs.lvl_322Code.GDBullet_95955Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595951Objects1Objects = Hashtable.newFrom({"Bullet_1": gdjs.lvl_322Code.GDBullet_95951Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDMecha_95959595BossObjects1Objects = Hashtable.newFrom({"Mecha_Boss": gdjs.lvl_322Code.GDMecha_9595BossObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects = Hashtable.newFrom({"Tileset_Piece_33": gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects = Hashtable.newFrom({"BlueFlame": gdjs.lvl_322Code.GDBlueFlameObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects = Hashtable.newFrom({"BlueFlame": gdjs.lvl_322Code.GDBlueFlameObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBarrierObjects1Objects = Hashtable.newFrom({"Barrier": gdjs.lvl_322Code.GDBarrierObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects = Hashtable.newFrom({"BlueFlame": gdjs.lvl_322Code.GDBlueFlameObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects = Hashtable.newFrom({"Tileset_Piece_33": gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects = Hashtable.newFrom({"BlueFlame": gdjs.lvl_322Code.GDBlueFlameObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.lvl_322Code.GDWallObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects = Hashtable.newFrom({"BlueFlame": gdjs.lvl_322Code.GDBlueFlameObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959561Objects1Objects = Hashtable.newFrom({"Tileset_Piece_61": gdjs.lvl_322Code.GDTileset_9595Piece_959561Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDMissileObjects1Objects = Hashtable.newFrom({"Missile": gdjs.lvl_322Code.GDMissileObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDMissileObjects1Objects = Hashtable.newFrom({"Missile": gdjs.lvl_322Code.GDMissileObjects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_322Code.GDScout_95953Objects1});
gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDRedExplosionObjects1Objects = Hashtable.newFrom({"RedExplosion": gdjs.lvl_322Code.GDRedExplosionObjects1});
gdjs.lvl_322Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Laser_Spikes"), gdjs.lvl_322Code.GDLaser_9595SpikesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDLaser_95959595SpikesObjects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
gdjs.lvl_322Code.GDBlood_9595SpotObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlood_95959595SpotObjects1Objects, (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointY("")), "");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.lvl_322Code.GDSawObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDSawObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.lvl_322Code.GDBarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBarrierObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laser_Spikes"), gdjs.lvl_322Code.GDLaser_9595SpikesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tileset_Piece_7"), gdjs.lvl_322Code.GDTileset_9595Piece_95957Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDLaser_95959595SpikesObjects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_959595957Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDLaser_9595SpikesObjects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDLaser_9595SpikesObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDLaser_9595SpikesObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Blue_button"), gdjs.lvl_322Code.GDBlue_9595buttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlue_95959595buttonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.lvl_322Code.GDBarrierObjects1);
{for(var i = 0, len = gdjs.lvl_322Code.GDBarrierObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDBarrierObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tileset_Piece_6"), gdjs.lvl_322Code.GDTileset_9595Piece_95956Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_959595956Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mecha_Boss"), gdjs.lvl_322Code.GDMecha_9595BossObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tileset_Piece_33"), gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDMecha_95959595BossObjects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDMecha_9595BossObjects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDMecha_9595BossObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDMecha_9595BossObjects1[i].clearForces();
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tileset_Piece_2"), gdjs.lvl_322Code.GDTileset_9595Piece_95952Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_959595952Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
gdjs.copyArray(runtimeScene.getObjects("moon"), gdjs.lvl_322Code.GDmoonObjects1);
gdjs.lvl_322Code.GDBullet_95955Objects1.length = 0;

{for(var i = 0, len = gdjs.lvl_322Code.GDmoonObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDmoonObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.lvl_322Code.GDmoonObjects1[i].getPointX("")), (gdjs.lvl_322Code.GDmoonObjects1[i].getPointY("")), gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects, (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointY("")), 100, null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
gdjs.lvl_322Code.GDBullet_95951Objects1.length = 0;

{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.lvl_322Code.GDScout_95953Objects1[i].getPointX("")), (gdjs.lvl_322Code.GDScout_95953Objects1[i].getPointY("")), gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595951Objects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 400, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_5"), gdjs.lvl_322Code.GDBullet_95955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_5"), gdjs.lvl_322Code.GDBullet_95955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.lvl_322Code.GDWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDBullet_95955Objects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDBullet_95955Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDBullet_95955Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_5"), gdjs.lvl_322Code.GDBullet_95955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tileset_Piece_33"), gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDBullet_95955Objects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDBullet_95955Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDBullet_95955Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.lvl_322Code.GDBarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullet_5"), gdjs.lvl_322Code.GDBullet_95955Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBarrierObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDBullet_95955Objects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDBullet_95955Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDBullet_95955Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_1"), gdjs.lvl_322Code.GDBullet_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Bullet_5"), gdjs.lvl_322Code.GDBullet_95955Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595951Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDBullet_95951Objects1 */
/* Reuse gdjs.lvl_322Code.GDBullet_95955Objects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDBullet_95955Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDBullet_95955Objects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.lvl_322Code.GDBullet_95951Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDBullet_95951Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].getBehavior("HorizontalDash").SimulateDashKey(null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tileset_Piece_33"), gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Mecha_Boss"), gdjs.lvl_322Code.GDMecha_9595BossObjects1);
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
gdjs.lvl_322Code.GDBullet_95955Objects1.length = 0;

{for(var i = 0, len = gdjs.lvl_322Code.GDMecha_9595BossObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDMecha_9595BossObjects1[i].getBehavior("FireBullet").FireTowardObject((gdjs.lvl_322Code.GDMecha_9595BossObjects1[i].getPointX("")), (gdjs.lvl_322Code.GDMecha_9595BossObjects1[i].getPointY("")), gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595955Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, 900, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mecha_Boss"), gdjs.lvl_322Code.GDMecha_9595BossObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_322Code.GDMecha_9595BossObjects1.length;i<l;++i) {
    if ( gdjs.lvl_322Code.GDMecha_9595BossObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_322Code.GDMecha_9595BossObjects1[k] = gdjs.lvl_322Code.GDMecha_9595BossObjects1[i];
        ++k;
    }
}
gdjs.lvl_322Code.GDMecha_9595BossObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDMecha_9595BossObjects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDMecha_9595BossObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDMecha_9595BossObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mecha_Boss"), gdjs.lvl_322Code.GDMecha_9595BossObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_322Code.GDMecha_9595BossObjects1.length;i<l;++i) {
    if ( gdjs.lvl_322Code.GDMecha_9595BossObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.lvl_322Code.GDMecha_9595BossObjects1[k] = gdjs.lvl_322Code.GDMecha_9595BossObjects1[i];
        ++k;
    }
}
gdjs.lvl_322Code.GDMecha_9595BossObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("moon"), gdjs.lvl_322Code.GDmoonObjects1);
{for(var i = 0, len = gdjs.lvl_322Code.GDmoonObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDmoonObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_1"), gdjs.lvl_322Code.GDBullet_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Mecha_Boss"), gdjs.lvl_322Code.GDMecha_9595BossObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBullet_959595951Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDMecha_95959595BossObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDMecha_9595BossObjects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDMecha_9595BossObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDMecha_9595BossObjects1[i].getBehavior("Animation").setAnimationName("Death");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tileset_Piece_33"), gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
gdjs.copyArray(runtimeScene.getObjects("moon"), gdjs.lvl_322Code.GDmoonObjects1);
gdjs.lvl_322Code.GDBlueFlameObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_322Code.GDmoonObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDmoonObjects1[i].getBehavior("FireBullet").FireTowardObject((gdjs.lvl_322Code.GDmoonObjects1[i].getPointX("")), (gdjs.lvl_322Code.GDmoonObjects1[i].getPointY("")), gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, 250, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.lvl_322Code.GDBarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueFlame"), gdjs.lvl_322Code.GDBlueFlameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBarrierObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDBlueFlameObjects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDBlueFlameObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDBlueFlameObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueFlame"), gdjs.lvl_322Code.GDBlueFlameObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tileset_Piece_33"), gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959533Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDBlueFlameObjects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDBlueFlameObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDBlueFlameObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueFlame"), gdjs.lvl_322Code.GDBlueFlameObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.lvl_322Code.GDWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDBlueFlameObjects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDBlueFlameObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDBlueFlameObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueFlame"), gdjs.lvl_322Code.GDBlueFlameObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDBlueFlameObjects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tileset_Piece_61"), gdjs.lvl_322Code.GDTileset_9595Piece_959561Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDTileset_95959595Piece_9595959561Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.lvl_322Code.GDGunObjects1);
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
gdjs.lvl_322Code.GDMissileObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_322Code.GDGunObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDGunObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.lvl_322Code.GDGunObjects1[i].getPointX("")), (gdjs.lvl_322Code.GDGunObjects1[i].getPointY("")), gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDMissileObjects1Objects, (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointY("")), 100, null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Missile"), gdjs.lvl_322Code.GDMissileObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_322Code.GDMissileObjects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDMissileObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointY("")));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Missile"), gdjs.lvl_322Code.GDMissileObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDMissileObjects1Objects, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDScout_959595953Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_322Code.GDScout_95953Objects1 */
gdjs.lvl_322Code.GDRedExplosionObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.lvl_322Code.mapOfGDgdjs_9546lvl_9595322Code_9546GDRedExplosionObjects1Objects, (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_322Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_322Code.GDScout_95953Objects1[0].getPointY("")), "");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_322Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_322Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_322Code.GDScout_95953Objects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


};

gdjs.lvl_322Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl_322Code.GDcloud_95952Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95952Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95954Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95954Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95951Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95951Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95953Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95953Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95955Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95955Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95956Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95956Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95957Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95957Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95958Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95958Objects2.length = 0;
gdjs.lvl_322Code.GDCastles_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDCastles_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDmoonObjects1.length = 0;
gdjs.lvl_322Code.GDmoonObjects2.length = 0;
gdjs.lvl_322Code.GDfenceObjects1.length = 0;
gdjs.lvl_322Code.GDfenceObjects2.length = 0;
gdjs.lvl_322Code.GDDesert_9595Background_95952Objects1.length = 0;
gdjs.lvl_322Code.GDDesert_9595Background_95952Objects2.length = 0;
gdjs.lvl_322Code.GDEmpty_9595Cloud_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDEmpty_9595Cloud_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDForest_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDForest_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDFall_9595Trees_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDFall_9595Trees_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDDesert_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDDesert_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDForest_9595Background_95952Objects1.length = 0;
gdjs.lvl_322Code.GDForest_9595Background_95952Objects2.length = 0;
gdjs.lvl_322Code.GDGrass_9595and_9595Tree_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDGrass_9595and_9595Tree_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95952Objects1.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95952Objects2.length = 0;
gdjs.lvl_322Code.GDBackground_9595MountainsObjects1.length = 0;
gdjs.lvl_322Code.GDBackground_9595MountainsObjects2.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95953Objects1.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95953Objects2.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95951Objects1.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95951Objects2.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95954Objects1.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95954Objects2.length = 0;
gdjs.lvl_322Code.GDGround_9595Layer_95951Objects1.length = 0;
gdjs.lvl_322Code.GDGround_9595Layer_95951Objects2.length = 0;
gdjs.lvl_322Code.GDLarge_9595hillsObjects1.length = 0;
gdjs.lvl_322Code.GDLarge_9595hillsObjects2.length = 0;
gdjs.lvl_322Code.GDAlternative_9595castle_9595wallObjects1.length = 0;
gdjs.lvl_322Code.GDAlternative_9595castle_9595wallObjects2.length = 0;
gdjs.lvl_322Code.GDGround_9595Layer_95952Objects1.length = 0;
gdjs.lvl_322Code.GDGround_9595Layer_95952Objects2.length = 0;
gdjs.lvl_322Code.GDHillsObjects1.length = 0;
gdjs.lvl_322Code.GDHillsObjects2.length = 0;
gdjs.lvl_322Code.GDCastle_9595WallObjects1.length = 0;
gdjs.lvl_322Code.GDCastle_9595WallObjects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95953Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95953Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95951Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95951Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95952Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95952Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95953Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95953Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95952Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95952Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95951Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95951Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95954Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95954Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95955Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95955Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95957Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95957Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95956Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95956Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95958Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95958Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95951Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95951Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95955Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95955Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95952Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95952Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95953Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95953Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95954Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95954Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95956Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95956Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95957Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95957Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95951Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95951Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95958Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95958Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95952Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95952Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95953Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95953Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95954Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95954Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95955Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95955Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95957Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95957Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95956Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95956Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95958Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95958Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959510Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959510Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95954Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95954Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95955Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95955Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95956Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95956Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95957Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95957Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95958Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95958Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95959Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95959Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959511Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959511Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959512Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959512Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95953Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95953Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95951Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95951Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959513Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959513Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95952Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95952Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95954Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95954Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95955Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95955Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95956Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95956Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95951Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95951Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95957Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95957Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95958Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95958Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95952Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95952Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95953Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95953Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95955Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95955Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95956Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95956Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95954Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95954Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95957Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95957Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95958Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95958Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95956Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95956Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959560Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959560Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959552Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959552Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959559Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959559Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959558Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959558Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959557Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959557Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959561Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959561Objects2.length = 0;
gdjs.lvl_322Code.GDBarrierObjects1.length = 0;
gdjs.lvl_322Code.GDBarrierObjects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95957Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95957Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95958Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95958Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959563Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959563Objects2.length = 0;
gdjs.lvl_322Code.GDElectric_9595TurretObjects1.length = 0;
gdjs.lvl_322Code.GDElectric_9595TurretObjects2.length = 0;
gdjs.lvl_322Code.GDLaser_9595SpikesObjects1.length = 0;
gdjs.lvl_322Code.GDLaser_9595SpikesObjects2.length = 0;
gdjs.lvl_322Code.GDLaser_9595TurretObjects1.length = 0;
gdjs.lvl_322Code.GDLaser_9595TurretObjects2.length = 0;
gdjs.lvl_322Code.GDSawObjects1.length = 0;
gdjs.lvl_322Code.GDSawObjects2.length = 0;
gdjs.lvl_322Code.GDWallObjects1.length = 0;
gdjs.lvl_322Code.GDWallObjects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959512Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959512Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959517Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959517Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959513Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959513Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959510Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959510Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959519Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959519Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95952Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95952Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959520Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959520Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959526Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959526Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959527Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959527Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95953Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95953Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959548Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959548Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959542Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959542Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959550Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959550Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959553Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959553Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959554Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959554Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959555Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959555Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959556Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959556Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959562Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959562Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95959Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95959Objects2.length = 0;
gdjs.lvl_322Code.GDGunObjects1.length = 0;
gdjs.lvl_322Code.GDGunObjects2.length = 0;
gdjs.lvl_322Code.GDBullet_95955Objects1.length = 0;
gdjs.lvl_322Code.GDBullet_95955Objects2.length = 0;
gdjs.lvl_322Code.GDBlood_9595SpotObjects1.length = 0;
gdjs.lvl_322Code.GDBlood_9595SpotObjects2.length = 0;
gdjs.lvl_322Code.GDBlue_9595buttonObjects1.length = 0;
gdjs.lvl_322Code.GDBlue_9595buttonObjects2.length = 0;
gdjs.lvl_322Code.GDMecha_9595BossObjects1.length = 0;
gdjs.lvl_322Code.GDMecha_9595BossObjects2.length = 0;
gdjs.lvl_322Code.GDBullet_95951Objects1.length = 0;
gdjs.lvl_322Code.GDBullet_95951Objects2.length = 0;
gdjs.lvl_322Code.GDBulletObjects1.length = 0;
gdjs.lvl_322Code.GDBulletObjects2.length = 0;
gdjs.lvl_322Code.GDBlueFlameObjects1.length = 0;
gdjs.lvl_322Code.GDBlueFlameObjects2.length = 0;
gdjs.lvl_322Code.GDWall_9595for_9595Blue_9595FloorObjects1.length = 0;
gdjs.lvl_322Code.GDWall_9595for_9595Blue_9595FloorObjects2.length = 0;
gdjs.lvl_322Code.GDMissileObjects1.length = 0;
gdjs.lvl_322Code.GDMissileObjects2.length = 0;
gdjs.lvl_322Code.GDRock_95955Objects1.length = 0;
gdjs.lvl_322Code.GDRock_95955Objects2.length = 0;
gdjs.lvl_322Code.GDRedExplosionObjects1.length = 0;
gdjs.lvl_322Code.GDRedExplosionObjects2.length = 0;
gdjs.lvl_322Code.GDBoss_9595GolemObjects1.length = 0;
gdjs.lvl_322Code.GDBoss_9595GolemObjects2.length = 0;
gdjs.lvl_322Code.GDSmall_9595CastleObjects1.length = 0;
gdjs.lvl_322Code.GDSmall_9595CastleObjects2.length = 0;

gdjs.lvl_322Code.eventsList0(runtimeScene);
gdjs.lvl_322Code.GDcloud_95952Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95952Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95954Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95954Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95951Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95951Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95953Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95953Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95955Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95955Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95956Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95956Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95957Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95957Objects2.length = 0;
gdjs.lvl_322Code.GDcloud_95958Objects1.length = 0;
gdjs.lvl_322Code.GDcloud_95958Objects2.length = 0;
gdjs.lvl_322Code.GDCastles_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDCastles_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDmoonObjects1.length = 0;
gdjs.lvl_322Code.GDmoonObjects2.length = 0;
gdjs.lvl_322Code.GDfenceObjects1.length = 0;
gdjs.lvl_322Code.GDfenceObjects2.length = 0;
gdjs.lvl_322Code.GDDesert_9595Background_95952Objects1.length = 0;
gdjs.lvl_322Code.GDDesert_9595Background_95952Objects2.length = 0;
gdjs.lvl_322Code.GDEmpty_9595Cloud_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDEmpty_9595Cloud_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDForest_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDForest_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDFall_9595Trees_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDFall_9595Trees_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDDesert_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDDesert_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDForest_9595Background_95952Objects1.length = 0;
gdjs.lvl_322Code.GDForest_9595Background_95952Objects2.length = 0;
gdjs.lvl_322Code.GDGrass_9595and_9595Tree_9595BackgroundObjects1.length = 0;
gdjs.lvl_322Code.GDGrass_9595and_9595Tree_9595BackgroundObjects2.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95952Objects1.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95952Objects2.length = 0;
gdjs.lvl_322Code.GDBackground_9595MountainsObjects1.length = 0;
gdjs.lvl_322Code.GDBackground_9595MountainsObjects2.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95953Objects1.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95953Objects2.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95951Objects1.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95951Objects2.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95954Objects1.length = 0;
gdjs.lvl_322Code.GDCloud_9595layer_95954Objects2.length = 0;
gdjs.lvl_322Code.GDGround_9595Layer_95951Objects1.length = 0;
gdjs.lvl_322Code.GDGround_9595Layer_95951Objects2.length = 0;
gdjs.lvl_322Code.GDLarge_9595hillsObjects1.length = 0;
gdjs.lvl_322Code.GDLarge_9595hillsObjects2.length = 0;
gdjs.lvl_322Code.GDAlternative_9595castle_9595wallObjects1.length = 0;
gdjs.lvl_322Code.GDAlternative_9595castle_9595wallObjects2.length = 0;
gdjs.lvl_322Code.GDGround_9595Layer_95952Objects1.length = 0;
gdjs.lvl_322Code.GDGround_9595Layer_95952Objects2.length = 0;
gdjs.lvl_322Code.GDHillsObjects1.length = 0;
gdjs.lvl_322Code.GDHillsObjects2.length = 0;
gdjs.lvl_322Code.GDCastle_9595WallObjects1.length = 0;
gdjs.lvl_322Code.GDCastle_9595WallObjects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95953Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95953Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95951Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95951Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95952Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95952Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95953Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95953Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95952Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95952Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95951Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95951Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95954Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95954Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95955Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95955Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95957Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95957Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95956Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95956Objects2.length = 0;
gdjs.lvl_322Code.GDBard_95958Objects1.length = 0;
gdjs.lvl_322Code.GDBard_95958Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95951Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95951Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95955Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95955Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95952Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95952Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95953Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95953Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95954Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95954Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95956Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95956Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95957Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95957Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95951Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95951Objects2.length = 0;
gdjs.lvl_322Code.GDConjurer_95958Objects1.length = 0;
gdjs.lvl_322Code.GDConjurer_95958Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95952Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95952Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95953Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95953Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95954Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95954Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95955Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95955Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95957Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95957Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95956Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95956Objects2.length = 0;
gdjs.lvl_322Code.GDDevout_95958Objects1.length = 0;
gdjs.lvl_322Code.GDDevout_95958Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959510Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959510Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95954Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95954Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95955Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95955Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95956Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95956Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95957Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95957Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95958Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95958Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95959Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_95959Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959511Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959511Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959512Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959512Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95953Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95953Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95951Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95951Objects2.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959513Objects1.length = 0;
gdjs.lvl_322Code.GDGeneric_9595Character_959513Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95952Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95952Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95954Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95954Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95955Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95955Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95956Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95956Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95951Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95951Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95957Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95957Objects2.length = 0;
gdjs.lvl_322Code.GDScout_95958Objects1.length = 0;
gdjs.lvl_322Code.GDScout_95958Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95952Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95952Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95953Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95953Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95955Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95955Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95956Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95956Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95954Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95954Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95957Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95957Objects2.length = 0;
gdjs.lvl_322Code.GDSoldier_95958Objects1.length = 0;
gdjs.lvl_322Code.GDSoldier_95958Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95956Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95956Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959560Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959560Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959552Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959552Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959559Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959559Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959558Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959558Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959557Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959557Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959561Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959561Objects2.length = 0;
gdjs.lvl_322Code.GDBarrierObjects1.length = 0;
gdjs.lvl_322Code.GDBarrierObjects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95957Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95957Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95958Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95958Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959563Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959563Objects2.length = 0;
gdjs.lvl_322Code.GDElectric_9595TurretObjects1.length = 0;
gdjs.lvl_322Code.GDElectric_9595TurretObjects2.length = 0;
gdjs.lvl_322Code.GDLaser_9595SpikesObjects1.length = 0;
gdjs.lvl_322Code.GDLaser_9595SpikesObjects2.length = 0;
gdjs.lvl_322Code.GDLaser_9595TurretObjects1.length = 0;
gdjs.lvl_322Code.GDLaser_9595TurretObjects2.length = 0;
gdjs.lvl_322Code.GDSawObjects1.length = 0;
gdjs.lvl_322Code.GDSawObjects2.length = 0;
gdjs.lvl_322Code.GDWallObjects1.length = 0;
gdjs.lvl_322Code.GDWallObjects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959512Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959512Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959517Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959517Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959513Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959513Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959510Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959510Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959519Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959519Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95952Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95952Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959520Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959520Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959526Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959526Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959527Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959527Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95953Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95953Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959548Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959548Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959542Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959542Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959533Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959550Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959550Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959553Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959553Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959554Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959554Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959555Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959555Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959556Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959556Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959562Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_959562Objects2.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95959Objects1.length = 0;
gdjs.lvl_322Code.GDTileset_9595Piece_95959Objects2.length = 0;
gdjs.lvl_322Code.GDGunObjects1.length = 0;
gdjs.lvl_322Code.GDGunObjects2.length = 0;
gdjs.lvl_322Code.GDBullet_95955Objects1.length = 0;
gdjs.lvl_322Code.GDBullet_95955Objects2.length = 0;
gdjs.lvl_322Code.GDBlood_9595SpotObjects1.length = 0;
gdjs.lvl_322Code.GDBlood_9595SpotObjects2.length = 0;
gdjs.lvl_322Code.GDBlue_9595buttonObjects1.length = 0;
gdjs.lvl_322Code.GDBlue_9595buttonObjects2.length = 0;
gdjs.lvl_322Code.GDMecha_9595BossObjects1.length = 0;
gdjs.lvl_322Code.GDMecha_9595BossObjects2.length = 0;
gdjs.lvl_322Code.GDBullet_95951Objects1.length = 0;
gdjs.lvl_322Code.GDBullet_95951Objects2.length = 0;
gdjs.lvl_322Code.GDBulletObjects1.length = 0;
gdjs.lvl_322Code.GDBulletObjects2.length = 0;
gdjs.lvl_322Code.GDBlueFlameObjects1.length = 0;
gdjs.lvl_322Code.GDBlueFlameObjects2.length = 0;
gdjs.lvl_322Code.GDWall_9595for_9595Blue_9595FloorObjects1.length = 0;
gdjs.lvl_322Code.GDWall_9595for_9595Blue_9595FloorObjects2.length = 0;
gdjs.lvl_322Code.GDMissileObjects1.length = 0;
gdjs.lvl_322Code.GDMissileObjects2.length = 0;
gdjs.lvl_322Code.GDRock_95955Objects1.length = 0;
gdjs.lvl_322Code.GDRock_95955Objects2.length = 0;
gdjs.lvl_322Code.GDRedExplosionObjects1.length = 0;
gdjs.lvl_322Code.GDRedExplosionObjects2.length = 0;
gdjs.lvl_322Code.GDBoss_9595GolemObjects1.length = 0;
gdjs.lvl_322Code.GDBoss_9595GolemObjects2.length = 0;
gdjs.lvl_322Code.GDSmall_9595CastleObjects1.length = 0;
gdjs.lvl_322Code.GDSmall_9595CastleObjects2.length = 0;


return;

}

gdjs['lvl_322Code'] = gdjs.lvl_322Code;
