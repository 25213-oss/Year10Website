gdjs.lvl_323Code = {};
gdjs.lvl_323Code.localVariables = [];
gdjs.lvl_323Code.idToCallbackMap = new Map();
gdjs.lvl_323Code.GDScout_95953Objects1= [];
gdjs.lvl_323Code.GDScout_95953Objects2= [];
gdjs.lvl_323Code.GDSkullObjects1= [];
gdjs.lvl_323Code.GDSkullObjects2= [];
gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1= [];
gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects2= [];
gdjs.lvl_323Code.GDDead_9595treeObjects1= [];
gdjs.lvl_323Code.GDDead_9595treeObjects2= [];
gdjs.lvl_323Code.GDBoss_9595GolemObjects1= [];
gdjs.lvl_323Code.GDBoss_9595GolemObjects2= [];
gdjs.lvl_323Code.GDHigh_9595spikesObjects1= [];
gdjs.lvl_323Code.GDHigh_9595spikesObjects2= [];
gdjs.lvl_323Code.GDBush_9595_95951_9595Objects1= [];
gdjs.lvl_323Code.GDBush_9595_95951_9595Objects2= [];
gdjs.lvl_323Code.GDSummer_9595Tile_9595Platform_9595RightObjects1= [];
gdjs.lvl_323Code.GDSummer_9595Tile_9595Platform_9595RightObjects2= [];
gdjs.lvl_323Code.GDWinter_9595Tile_9595Dirt_9595Corner_9595LeftObjects1= [];
gdjs.lvl_323Code.GDWinter_9595Tile_9595Dirt_9595Corner_9595LeftObjects2= [];
gdjs.lvl_323Code.GDBasicFlameObjects1= [];
gdjs.lvl_323Code.GDBasicFlameObjects2= [];
gdjs.lvl_323Code.GDBasicSparksObjects1= [];
gdjs.lvl_323Code.GDBasicSparksObjects2= [];
gdjs.lvl_323Code.GDBasicSmokeObjects1= [];
gdjs.lvl_323Code.GDBasicSmokeObjects2= [];
gdjs.lvl_323Code.GDBasicFlame2Objects1= [];
gdjs.lvl_323Code.GDBasicFlame2Objects2= [];
gdjs.lvl_323Code.GDBasicExplosionEnergySparksObjects1= [];
gdjs.lvl_323Code.GDBasicExplosionEnergySparksObjects2= [];
gdjs.lvl_323Code.GDBasicExplosionSmoothObjects1= [];
gdjs.lvl_323Code.GDBasicExplosionSmoothObjects2= [];
gdjs.lvl_323Code.GDBasicExplosionEnergyObjects1= [];
gdjs.lvl_323Code.GDBasicExplosionEnergyObjects2= [];
gdjs.lvl_323Code.GDLightningTextureObjects1= [];
gdjs.lvl_323Code.GDLightningTextureObjects2= [];
gdjs.lvl_323Code.GDBasicFlame3Objects1= [];
gdjs.lvl_323Code.GDBasicFlame3Objects2= [];
gdjs.lvl_323Code.GDBasicSparks2Objects1= [];
gdjs.lvl_323Code.GDBasicSparks2Objects2= [];
gdjs.lvl_323Code.GDMagicObjects1= [];
gdjs.lvl_323Code.GDMagicObjects2= [];
gdjs.lvl_323Code.GDMagic2Objects1= [];
gdjs.lvl_323Code.GDMagic2Objects2= [];
gdjs.lvl_323Code.GDStarSparksObjects1= [];
gdjs.lvl_323Code.GDStarSparksObjects2= [];
gdjs.lvl_323Code.GDPixelFlameObjects1= [];
gdjs.lvl_323Code.GDPixelFlameObjects2= [];
gdjs.lvl_323Code.GDPixelSmokeObjects1= [];
gdjs.lvl_323Code.GDPixelSmokeObjects2= [];
gdjs.lvl_323Code.GDBlueExplosionObjects1= [];
gdjs.lvl_323Code.GDBlueExplosionObjects2= [];
gdjs.lvl_323Code.GDBlueFlameObjects1= [];
gdjs.lvl_323Code.GDBlueFlameObjects2= [];
gdjs.lvl_323Code.GDRedFlameObjects1= [];
gdjs.lvl_323Code.GDRedFlameObjects2= [];
gdjs.lvl_323Code.GDRedExplosionObjects1= [];
gdjs.lvl_323Code.GDRedExplosionObjects2= [];
gdjs.lvl_323Code.GDBubblesSprayObjects1= [];
gdjs.lvl_323Code.GDBubblesSprayObjects2= [];
gdjs.lvl_323Code.GDBubblesObjects1= [];
gdjs.lvl_323Code.GDBubblesObjects2= [];
gdjs.lvl_323Code.GDBubblesStreamObjects1= [];
gdjs.lvl_323Code.GDBubblesStreamObjects2= [];
gdjs.lvl_323Code.GDCartoonSmokeObjects1= [];
gdjs.lvl_323Code.GDCartoonSmokeObjects2= [];
gdjs.lvl_323Code.GDCartoonSmokeBlastObjects1= [];
gdjs.lvl_323Code.GDCartoonSmokeBlastObjects2= [];
gdjs.lvl_323Code.GDExplosion1Objects1= [];
gdjs.lvl_323Code.GDExplosion1Objects2= [];
gdjs.lvl_323Code.GDExplosion3Objects1= [];
gdjs.lvl_323Code.GDExplosion3Objects2= [];
gdjs.lvl_323Code.GDExplosion2Objects1= [];
gdjs.lvl_323Code.GDExplosion2Objects2= [];
gdjs.lvl_323Code.GDFlameObjects1= [];
gdjs.lvl_323Code.GDFlameObjects2= [];
gdjs.lvl_323Code.GDGasObjects1= [];
gdjs.lvl_323Code.GDGasObjects2= [];
gdjs.lvl_323Code.GDPixelTrailObjects1= [];
gdjs.lvl_323Code.GDPixelTrailObjects2= [];
gdjs.lvl_323Code.GDRainObjects1= [];
gdjs.lvl_323Code.GDRainObjects2= [];
gdjs.lvl_323Code.GDSmokeObjects1= [];
gdjs.lvl_323Code.GDSmokeObjects2= [];
gdjs.lvl_323Code.GDPixiDustObjects1= [];
gdjs.lvl_323Code.GDPixiDustObjects2= [];
gdjs.lvl_323Code.GDSnowObjects1= [];
gdjs.lvl_323Code.GDSnowObjects2= [];
gdjs.lvl_323Code.GDSparksObjects1= [];
gdjs.lvl_323Code.GDSparksObjects2= [];
gdjs.lvl_323Code.GDTrailObjects1= [];
gdjs.lvl_323Code.GDTrailObjects2= [];
gdjs.lvl_323Code.GDVerticalBubblesObjects1= [];
gdjs.lvl_323Code.GDVerticalBubblesObjects2= [];
gdjs.lvl_323Code.GDLaserObjects1= [];
gdjs.lvl_323Code.GDLaserObjects2= [];
gdjs.lvl_323Code.GDTikTokObjects1= [];
gdjs.lvl_323Code.GDTikTokObjects2= [];
gdjs.lvl_323Code.GDWatermelonObjects1= [];
gdjs.lvl_323Code.GDWatermelonObjects2= [];
gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1= [];
gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects2= [];
gdjs.lvl_323Code.GDTile_959515Objects1= [];
gdjs.lvl_323Code.GDTile_959515Objects2= [];
gdjs.lvl_323Code.GDdebrisObjects1= [];
gdjs.lvl_323Code.GDdebrisObjects2= [];
gdjs.lvl_323Code.GDNewSpriteObjects1= [];
gdjs.lvl_323Code.GDNewSpriteObjects2= [];
gdjs.lvl_323Code.GDBushObjects1= [];
gdjs.lvl_323Code.GDBushObjects2= [];
gdjs.lvl_323Code.GDScout_95952Objects1= [];
gdjs.lvl_323Code.GDScout_95952Objects2= [];
gdjs.lvl_323Code.GDTiny_9595grassObjects1= [];
gdjs.lvl_323Code.GDTiny_9595grassObjects2= [];


gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBush_95959595_959595951_95959595Objects1Objects = Hashtable.newFrom({"Bush__1_": gdjs.lvl_323Code.GDBush_9595_95951_9595Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDHigh_95959595spikesObjects1Objects = Hashtable.newFrom({"High_spikes": gdjs.lvl_323Code.GDHigh_9595spikesObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBush_95959595_959595951_95959595Objects1Objects = Hashtable.newFrom({"Bush__1_": gdjs.lvl_323Code.GDBush_9595_95951_9595Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDHigh_95959595spikesObjects1Objects = Hashtable.newFrom({"High_spikes": gdjs.lvl_323Code.GDHigh_9595spikesObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects = Hashtable.newFrom({"Tile_10_tiled_sprite": gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDPixelTrailObjects1Objects = Hashtable.newFrom({"PixelTrail": gdjs.lvl_323Code.GDPixelTrailObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects = Hashtable.newFrom({"Tile_10_tiled_sprite": gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDRedExplosionObjects1Objects = Hashtable.newFrom({"RedExplosion": gdjs.lvl_323Code.GDRedExplosionObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects = Hashtable.newFrom({"Tile_10_tiled_sprite": gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDLaserObjects1Objects = Hashtable.newFrom({"Laser": gdjs.lvl_323Code.GDLaserObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects = Hashtable.newFrom({"Tile_10_tiled_sprite": gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBasicFlame3Objects1Objects = Hashtable.newFrom({"BasicFlame3": gdjs.lvl_323Code.GDBasicFlame3Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBushObjects1Objects = Hashtable.newFrom({"Bush": gdjs.lvl_323Code.GDBushObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDdebrisObjects1Objects = Hashtable.newFrom({"debris": gdjs.lvl_323Code.GDdebrisObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects = Hashtable.newFrom({"Tile_10_tiled_sprite": gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDdebrisObjects1Objects = Hashtable.newFrom({"debris": gdjs.lvl_323Code.GDdebrisObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDPixelTrailObjects1Objects = Hashtable.newFrom({"PixelTrail": gdjs.lvl_323Code.GDPixelTrailObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDdebrisObjects1Objects = Hashtable.newFrom({"debris": gdjs.lvl_323Code.GDdebrisObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDdebrisObjects1Objects = Hashtable.newFrom({"debris": gdjs.lvl_323Code.GDdebrisObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDLaserObjects1Objects = Hashtable.newFrom({"Laser": gdjs.lvl_323Code.GDLaserObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDPixelTrailObjects1Objects = Hashtable.newFrom({"PixelTrail": gdjs.lvl_323Code.GDPixelTrailObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDRedExplosionObjects1Objects = Hashtable.newFrom({"RedExplosion": gdjs.lvl_323Code.GDRedExplosionObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDStarSparksObjects1Objects = Hashtable.newFrom({"StarSparks": gdjs.lvl_323Code.GDStarSparksObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDStarSparksObjects1Objects = Hashtable.newFrom({"StarSparks": gdjs.lvl_323Code.GDStarSparksObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBoss_95959595GolemObjects1Objects = Hashtable.newFrom({"Boss_Golem": gdjs.lvl_323Code.GDBoss_9595GolemObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects = Hashtable.newFrom({"Tile_10_tiled_sprite": gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDGasObjects1Objects = Hashtable.newFrom({"Gas": gdjs.lvl_323Code.GDGasObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDGasObjects1Objects = Hashtable.newFrom({"Gas": gdjs.lvl_323Code.GDGasObjects1});
gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects = Hashtable.newFrom({"Scout_3": gdjs.lvl_323Code.GDScout_95953Objects1});
gdjs.lvl_323Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bush__1_"), gdjs.lvl_323Code.GDBush_9595_95951_9595Objects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBush_95959595_959595951_95959595Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("High_spikes"), gdjs.lvl_323Code.GDHigh_9595spikesObjects1);
{for(var i = 0, len = gdjs.lvl_323Code.GDHigh_9595spikesObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDHigh_9595spikesObjects1[i].getBehavior("LinearMovement").SetSpeedY(-90, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bush__1_"), gdjs.lvl_323Code.GDBush_9595_95951_9595Objects1);
gdjs.copyArray(runtimeScene.getObjects("High_spikes"), gdjs.lvl_323Code.GDHigh_9595spikesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDHigh_95959595spikesObjects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBush_95959595_959595951_95959595Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDHigh_9595spikesObjects1 */
{for(var i = 0, len = gdjs.lvl_323Code.GDHigh_9595spikesObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDHigh_9595spikesObjects1[i].getBehavior("LinearMovement").SetSpeedY(90, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("High_spikes"), gdjs.lvl_323Code.GDHigh_9595spikesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDHigh_95959595spikesObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tile_10_tiled_sprite"), gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
gdjs.copyArray(runtimeScene.getObjects("TikTok"), gdjs.lvl_323Code.GDTikTokObjects1);
gdjs.lvl_323Code.GDPixelTrailObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_323Code.GDTikTokObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDTikTokObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.lvl_323Code.GDTikTokObjects1[i].getPointX("")), (gdjs.lvl_323Code.GDTikTokObjects1[i].getPointY("")), gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDPixelTrailObjects1Objects, (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointY("")), 300, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tile_10_tiled_sprite"), gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss_Golem"), gdjs.lvl_323Code.GDBoss_9595GolemObjects1);
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
gdjs.lvl_323Code.GDRedExplosionObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_323Code.GDBoss_9595GolemObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDBoss_9595GolemObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.lvl_323Code.GDBoss_9595GolemObjects1[i].getPointX("")), (gdjs.lvl_323Code.GDBoss_9595GolemObjects1[i].getPointY("")), gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDRedExplosionObjects1Objects, (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointY("")), 100, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tile_10_tiled_sprite"), gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Laser"), gdjs.lvl_323Code.GDLaserObjects1);
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Watermelon"), gdjs.lvl_323Code.GDWatermelonObjects1);
{for(var i = 0, len = gdjs.lvl_323Code.GDLaserObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDLaserObjects1[i].setAngle(90);
}
}
{for(var i = 0, len = gdjs.lvl_323Code.GDWatermelonObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDWatermelonObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.lvl_323Code.GDWatermelonObjects1[i].getPointX("")), (gdjs.lvl_323Code.GDWatermelonObjects1[i].getPointY("")), gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDLaserObjects1Objects, (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointY("")), 500, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tile_10_tiled_sprite"), gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Strawberry_Ice_Cream"), gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1);
gdjs.lvl_323Code.GDBasicFlame3Objects1.length = 0;

{for(var i = 0, len = gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1[i].getPointX("")), (gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1[i].getPointY("")), gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBasicFlame3Objects1Objects, (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointY("")), 100, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bush"), gdjs.lvl_323Code.GDBushObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBushObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("debris"), gdjs.lvl_323Code.GDdebrisObjects1);
{for(var i = 0, len = gdjs.lvl_323Code.GDdebrisObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDdebrisObjects1[i].getBehavior("LinearMovement").SetSpeedY(270, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tile_10_tiled_sprite"), gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("debris"), gdjs.lvl_323Code.GDdebrisObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDdebrisObjects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDdebrisObjects1 */
{for(var i = 0, len = gdjs.lvl_323Code.GDdebrisObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDdebrisObjects1[i].clearForces();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("debris"), gdjs.lvl_323Code.GDdebrisObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDdebrisObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
gdjs.copyArray(runtimeScene.getObjects("TikTok"), gdjs.lvl_323Code.GDTikTokObjects1);
gdjs.lvl_323Code.GDPixelTrailObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_323Code.GDTikTokObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDTikTokObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.lvl_323Code.GDTikTokObjects1[i].getPointX("")), (gdjs.lvl_323Code.GDTikTokObjects1[i].getPointY("")), gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDPixelTrailObjects1Objects, (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointX("")), (( gdjs.lvl_323Code.GDScout_95953Objects1.length === 0 ) ? 0 :gdjs.lvl_323Code.GDScout_95953Objects1[0].getPointY("")), 300, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("debris"), gdjs.lvl_323Code.GDdebrisObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDdebrisObjects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDdebrisObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDdebrisObjects1 */
{for(var i = 0, len = gdjs.lvl_323Code.GDdebrisObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDdebrisObjects1[i].clearForces();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laser"), gdjs.lvl_323Code.GDLaserObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDLaserObjects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PixelTrail"), gdjs.lvl_323Code.GDPixelTrailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDPixelTrailObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedExplosion"), gdjs.lvl_323Code.GDRedExplosionObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDRedExplosionObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
gdjs.lvl_323Code.GDStarSparksObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95953Objects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.lvl_323Code.GDScout_95953Objects1[i].getPointX("")), (gdjs.lvl_323Code.GDScout_95953Objects1[i].getPointY("")), gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDStarSparksObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 400, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss_Golem"), gdjs.lvl_323Code.GDBoss_9595GolemObjects1);
gdjs.copyArray(runtimeScene.getObjects("StarSparks"), gdjs.lvl_323Code.GDStarSparksObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDStarSparksObjects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDBoss_95959595GolemObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29899668);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss_Golem"), gdjs.lvl_323Code.GDBoss_9595GolemObjects1);
{for(var i = 0, len = gdjs.lvl_323Code.GDBoss_9595GolemObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDBoss_9595GolemObjects1[i].getBehavior("Animation").setAnimationName("DEATH");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss_Golem"), gdjs.lvl_323Code.GDBoss_9595GolemObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl_323Code.GDBoss_9595GolemObjects1.length;i<l;++i) {
    if ( (gdjs.lvl_323Code.GDBoss_9595GolemObjects1[i].getBehavior("Animation").getAnimationName()).endsWith("DEATH") ) {
        isConditionTrue_0 = true;
        gdjs.lvl_323Code.GDBoss_9595GolemObjects1[k] = gdjs.lvl_323Code.GDBoss_9595GolemObjects1[i];
        ++k;
    }
}
gdjs.lvl_323Code.GDBoss_9595GolemObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDBoss_9595GolemObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Strawberry_Ice_Cream"), gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1);
gdjs.copyArray(runtimeScene.getObjects("TikTok"), gdjs.lvl_323Code.GDTikTokObjects1);
gdjs.copyArray(runtimeScene.getObjects("Watermelon"), gdjs.lvl_323Code.GDWatermelonObjects1);
{for(var i = 0, len = gdjs.lvl_323Code.GDBoss_9595GolemObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDBoss_9595GolemObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.lvl_323Code.GDTikTokObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDTikTokObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.lvl_323Code.GDWatermelonObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDWatermelonObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tile_10_tiled_sprite"), gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDTile_9595959510_95959595tiled_95959595spriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Strawberry_Ice_Cream"), gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1);
gdjs.lvl_323Code.GDGasObjects1.length = 0;

{for(var i = 0, len = gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1[i].getBehavior("FireBullet").FireTowardObject((gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1[i].getPointX("")), (gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1[i].getPointY("")), gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDGasObjects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, 700, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gas"), gdjs.lvl_323Code.GDGasObjects1);
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDGasObjects1Objects, gdjs.lvl_323Code.mapOfGDgdjs_9546lvl_9595323Code_9546GDScout_959595953Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_323Code.GDScout_95953Objects1 */
{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95953Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95953Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95953Objects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_3"), gdjs.lvl_323Code.GDScout_95953Objects1);
{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95953Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95953Objects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Scout_2"), gdjs.lvl_323Code.GDScout_95952Objects1);
{for(var i = 0, len = gdjs.lvl_323Code.GDScout_95952Objects1.length ;i < len;++i) {
    gdjs.lvl_323Code.GDScout_95952Objects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, 0, 0);
}
}
}

}


};

gdjs.lvl_323Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl_323Code.GDScout_95953Objects1.length = 0;
gdjs.lvl_323Code.GDScout_95953Objects2.length = 0;
gdjs.lvl_323Code.GDSkullObjects1.length = 0;
gdjs.lvl_323Code.GDSkullObjects2.length = 0;
gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1.length = 0;
gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects2.length = 0;
gdjs.lvl_323Code.GDDead_9595treeObjects1.length = 0;
gdjs.lvl_323Code.GDDead_9595treeObjects2.length = 0;
gdjs.lvl_323Code.GDBoss_9595GolemObjects1.length = 0;
gdjs.lvl_323Code.GDBoss_9595GolemObjects2.length = 0;
gdjs.lvl_323Code.GDHigh_9595spikesObjects1.length = 0;
gdjs.lvl_323Code.GDHigh_9595spikesObjects2.length = 0;
gdjs.lvl_323Code.GDBush_9595_95951_9595Objects1.length = 0;
gdjs.lvl_323Code.GDBush_9595_95951_9595Objects2.length = 0;
gdjs.lvl_323Code.GDSummer_9595Tile_9595Platform_9595RightObjects1.length = 0;
gdjs.lvl_323Code.GDSummer_9595Tile_9595Platform_9595RightObjects2.length = 0;
gdjs.lvl_323Code.GDWinter_9595Tile_9595Dirt_9595Corner_9595LeftObjects1.length = 0;
gdjs.lvl_323Code.GDWinter_9595Tile_9595Dirt_9595Corner_9595LeftObjects2.length = 0;
gdjs.lvl_323Code.GDBasicFlameObjects1.length = 0;
gdjs.lvl_323Code.GDBasicFlameObjects2.length = 0;
gdjs.lvl_323Code.GDBasicSparksObjects1.length = 0;
gdjs.lvl_323Code.GDBasicSparksObjects2.length = 0;
gdjs.lvl_323Code.GDBasicSmokeObjects1.length = 0;
gdjs.lvl_323Code.GDBasicSmokeObjects2.length = 0;
gdjs.lvl_323Code.GDBasicFlame2Objects1.length = 0;
gdjs.lvl_323Code.GDBasicFlame2Objects2.length = 0;
gdjs.lvl_323Code.GDBasicExplosionEnergySparksObjects1.length = 0;
gdjs.lvl_323Code.GDBasicExplosionEnergySparksObjects2.length = 0;
gdjs.lvl_323Code.GDBasicExplosionSmoothObjects1.length = 0;
gdjs.lvl_323Code.GDBasicExplosionSmoothObjects2.length = 0;
gdjs.lvl_323Code.GDBasicExplosionEnergyObjects1.length = 0;
gdjs.lvl_323Code.GDBasicExplosionEnergyObjects2.length = 0;
gdjs.lvl_323Code.GDLightningTextureObjects1.length = 0;
gdjs.lvl_323Code.GDLightningTextureObjects2.length = 0;
gdjs.lvl_323Code.GDBasicFlame3Objects1.length = 0;
gdjs.lvl_323Code.GDBasicFlame3Objects2.length = 0;
gdjs.lvl_323Code.GDBasicSparks2Objects1.length = 0;
gdjs.lvl_323Code.GDBasicSparks2Objects2.length = 0;
gdjs.lvl_323Code.GDMagicObjects1.length = 0;
gdjs.lvl_323Code.GDMagicObjects2.length = 0;
gdjs.lvl_323Code.GDMagic2Objects1.length = 0;
gdjs.lvl_323Code.GDMagic2Objects2.length = 0;
gdjs.lvl_323Code.GDStarSparksObjects1.length = 0;
gdjs.lvl_323Code.GDStarSparksObjects2.length = 0;
gdjs.lvl_323Code.GDPixelFlameObjects1.length = 0;
gdjs.lvl_323Code.GDPixelFlameObjects2.length = 0;
gdjs.lvl_323Code.GDPixelSmokeObjects1.length = 0;
gdjs.lvl_323Code.GDPixelSmokeObjects2.length = 0;
gdjs.lvl_323Code.GDBlueExplosionObjects1.length = 0;
gdjs.lvl_323Code.GDBlueExplosionObjects2.length = 0;
gdjs.lvl_323Code.GDBlueFlameObjects1.length = 0;
gdjs.lvl_323Code.GDBlueFlameObjects2.length = 0;
gdjs.lvl_323Code.GDRedFlameObjects1.length = 0;
gdjs.lvl_323Code.GDRedFlameObjects2.length = 0;
gdjs.lvl_323Code.GDRedExplosionObjects1.length = 0;
gdjs.lvl_323Code.GDRedExplosionObjects2.length = 0;
gdjs.lvl_323Code.GDBubblesSprayObjects1.length = 0;
gdjs.lvl_323Code.GDBubblesSprayObjects2.length = 0;
gdjs.lvl_323Code.GDBubblesObjects1.length = 0;
gdjs.lvl_323Code.GDBubblesObjects2.length = 0;
gdjs.lvl_323Code.GDBubblesStreamObjects1.length = 0;
gdjs.lvl_323Code.GDBubblesStreamObjects2.length = 0;
gdjs.lvl_323Code.GDCartoonSmokeObjects1.length = 0;
gdjs.lvl_323Code.GDCartoonSmokeObjects2.length = 0;
gdjs.lvl_323Code.GDCartoonSmokeBlastObjects1.length = 0;
gdjs.lvl_323Code.GDCartoonSmokeBlastObjects2.length = 0;
gdjs.lvl_323Code.GDExplosion1Objects1.length = 0;
gdjs.lvl_323Code.GDExplosion1Objects2.length = 0;
gdjs.lvl_323Code.GDExplosion3Objects1.length = 0;
gdjs.lvl_323Code.GDExplosion3Objects2.length = 0;
gdjs.lvl_323Code.GDExplosion2Objects1.length = 0;
gdjs.lvl_323Code.GDExplosion2Objects2.length = 0;
gdjs.lvl_323Code.GDFlameObjects1.length = 0;
gdjs.lvl_323Code.GDFlameObjects2.length = 0;
gdjs.lvl_323Code.GDGasObjects1.length = 0;
gdjs.lvl_323Code.GDGasObjects2.length = 0;
gdjs.lvl_323Code.GDPixelTrailObjects1.length = 0;
gdjs.lvl_323Code.GDPixelTrailObjects2.length = 0;
gdjs.lvl_323Code.GDRainObjects1.length = 0;
gdjs.lvl_323Code.GDRainObjects2.length = 0;
gdjs.lvl_323Code.GDSmokeObjects1.length = 0;
gdjs.lvl_323Code.GDSmokeObjects2.length = 0;
gdjs.lvl_323Code.GDPixiDustObjects1.length = 0;
gdjs.lvl_323Code.GDPixiDustObjects2.length = 0;
gdjs.lvl_323Code.GDSnowObjects1.length = 0;
gdjs.lvl_323Code.GDSnowObjects2.length = 0;
gdjs.lvl_323Code.GDSparksObjects1.length = 0;
gdjs.lvl_323Code.GDSparksObjects2.length = 0;
gdjs.lvl_323Code.GDTrailObjects1.length = 0;
gdjs.lvl_323Code.GDTrailObjects2.length = 0;
gdjs.lvl_323Code.GDVerticalBubblesObjects1.length = 0;
gdjs.lvl_323Code.GDVerticalBubblesObjects2.length = 0;
gdjs.lvl_323Code.GDLaserObjects1.length = 0;
gdjs.lvl_323Code.GDLaserObjects2.length = 0;
gdjs.lvl_323Code.GDTikTokObjects1.length = 0;
gdjs.lvl_323Code.GDTikTokObjects2.length = 0;
gdjs.lvl_323Code.GDWatermelonObjects1.length = 0;
gdjs.lvl_323Code.GDWatermelonObjects2.length = 0;
gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1.length = 0;
gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects2.length = 0;
gdjs.lvl_323Code.GDTile_959515Objects1.length = 0;
gdjs.lvl_323Code.GDTile_959515Objects2.length = 0;
gdjs.lvl_323Code.GDdebrisObjects1.length = 0;
gdjs.lvl_323Code.GDdebrisObjects2.length = 0;
gdjs.lvl_323Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl_323Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl_323Code.GDBushObjects1.length = 0;
gdjs.lvl_323Code.GDBushObjects2.length = 0;
gdjs.lvl_323Code.GDScout_95952Objects1.length = 0;
gdjs.lvl_323Code.GDScout_95952Objects2.length = 0;
gdjs.lvl_323Code.GDTiny_9595grassObjects1.length = 0;
gdjs.lvl_323Code.GDTiny_9595grassObjects2.length = 0;

gdjs.lvl_323Code.eventsList0(runtimeScene);
gdjs.lvl_323Code.GDScout_95953Objects1.length = 0;
gdjs.lvl_323Code.GDScout_95953Objects2.length = 0;
gdjs.lvl_323Code.GDSkullObjects1.length = 0;
gdjs.lvl_323Code.GDSkullObjects2.length = 0;
gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects1.length = 0;
gdjs.lvl_323Code.GDTile_959510_9595tiled_9595spriteObjects2.length = 0;
gdjs.lvl_323Code.GDDead_9595treeObjects1.length = 0;
gdjs.lvl_323Code.GDDead_9595treeObjects2.length = 0;
gdjs.lvl_323Code.GDBoss_9595GolemObjects1.length = 0;
gdjs.lvl_323Code.GDBoss_9595GolemObjects2.length = 0;
gdjs.lvl_323Code.GDHigh_9595spikesObjects1.length = 0;
gdjs.lvl_323Code.GDHigh_9595spikesObjects2.length = 0;
gdjs.lvl_323Code.GDBush_9595_95951_9595Objects1.length = 0;
gdjs.lvl_323Code.GDBush_9595_95951_9595Objects2.length = 0;
gdjs.lvl_323Code.GDSummer_9595Tile_9595Platform_9595RightObjects1.length = 0;
gdjs.lvl_323Code.GDSummer_9595Tile_9595Platform_9595RightObjects2.length = 0;
gdjs.lvl_323Code.GDWinter_9595Tile_9595Dirt_9595Corner_9595LeftObjects1.length = 0;
gdjs.lvl_323Code.GDWinter_9595Tile_9595Dirt_9595Corner_9595LeftObjects2.length = 0;
gdjs.lvl_323Code.GDBasicFlameObjects1.length = 0;
gdjs.lvl_323Code.GDBasicFlameObjects2.length = 0;
gdjs.lvl_323Code.GDBasicSparksObjects1.length = 0;
gdjs.lvl_323Code.GDBasicSparksObjects2.length = 0;
gdjs.lvl_323Code.GDBasicSmokeObjects1.length = 0;
gdjs.lvl_323Code.GDBasicSmokeObjects2.length = 0;
gdjs.lvl_323Code.GDBasicFlame2Objects1.length = 0;
gdjs.lvl_323Code.GDBasicFlame2Objects2.length = 0;
gdjs.lvl_323Code.GDBasicExplosionEnergySparksObjects1.length = 0;
gdjs.lvl_323Code.GDBasicExplosionEnergySparksObjects2.length = 0;
gdjs.lvl_323Code.GDBasicExplosionSmoothObjects1.length = 0;
gdjs.lvl_323Code.GDBasicExplosionSmoothObjects2.length = 0;
gdjs.lvl_323Code.GDBasicExplosionEnergyObjects1.length = 0;
gdjs.lvl_323Code.GDBasicExplosionEnergyObjects2.length = 0;
gdjs.lvl_323Code.GDLightningTextureObjects1.length = 0;
gdjs.lvl_323Code.GDLightningTextureObjects2.length = 0;
gdjs.lvl_323Code.GDBasicFlame3Objects1.length = 0;
gdjs.lvl_323Code.GDBasicFlame3Objects2.length = 0;
gdjs.lvl_323Code.GDBasicSparks2Objects1.length = 0;
gdjs.lvl_323Code.GDBasicSparks2Objects2.length = 0;
gdjs.lvl_323Code.GDMagicObjects1.length = 0;
gdjs.lvl_323Code.GDMagicObjects2.length = 0;
gdjs.lvl_323Code.GDMagic2Objects1.length = 0;
gdjs.lvl_323Code.GDMagic2Objects2.length = 0;
gdjs.lvl_323Code.GDStarSparksObjects1.length = 0;
gdjs.lvl_323Code.GDStarSparksObjects2.length = 0;
gdjs.lvl_323Code.GDPixelFlameObjects1.length = 0;
gdjs.lvl_323Code.GDPixelFlameObjects2.length = 0;
gdjs.lvl_323Code.GDPixelSmokeObjects1.length = 0;
gdjs.lvl_323Code.GDPixelSmokeObjects2.length = 0;
gdjs.lvl_323Code.GDBlueExplosionObjects1.length = 0;
gdjs.lvl_323Code.GDBlueExplosionObjects2.length = 0;
gdjs.lvl_323Code.GDBlueFlameObjects1.length = 0;
gdjs.lvl_323Code.GDBlueFlameObjects2.length = 0;
gdjs.lvl_323Code.GDRedFlameObjects1.length = 0;
gdjs.lvl_323Code.GDRedFlameObjects2.length = 0;
gdjs.lvl_323Code.GDRedExplosionObjects1.length = 0;
gdjs.lvl_323Code.GDRedExplosionObjects2.length = 0;
gdjs.lvl_323Code.GDBubblesSprayObjects1.length = 0;
gdjs.lvl_323Code.GDBubblesSprayObjects2.length = 0;
gdjs.lvl_323Code.GDBubblesObjects1.length = 0;
gdjs.lvl_323Code.GDBubblesObjects2.length = 0;
gdjs.lvl_323Code.GDBubblesStreamObjects1.length = 0;
gdjs.lvl_323Code.GDBubblesStreamObjects2.length = 0;
gdjs.lvl_323Code.GDCartoonSmokeObjects1.length = 0;
gdjs.lvl_323Code.GDCartoonSmokeObjects2.length = 0;
gdjs.lvl_323Code.GDCartoonSmokeBlastObjects1.length = 0;
gdjs.lvl_323Code.GDCartoonSmokeBlastObjects2.length = 0;
gdjs.lvl_323Code.GDExplosion1Objects1.length = 0;
gdjs.lvl_323Code.GDExplosion1Objects2.length = 0;
gdjs.lvl_323Code.GDExplosion3Objects1.length = 0;
gdjs.lvl_323Code.GDExplosion3Objects2.length = 0;
gdjs.lvl_323Code.GDExplosion2Objects1.length = 0;
gdjs.lvl_323Code.GDExplosion2Objects2.length = 0;
gdjs.lvl_323Code.GDFlameObjects1.length = 0;
gdjs.lvl_323Code.GDFlameObjects2.length = 0;
gdjs.lvl_323Code.GDGasObjects1.length = 0;
gdjs.lvl_323Code.GDGasObjects2.length = 0;
gdjs.lvl_323Code.GDPixelTrailObjects1.length = 0;
gdjs.lvl_323Code.GDPixelTrailObjects2.length = 0;
gdjs.lvl_323Code.GDRainObjects1.length = 0;
gdjs.lvl_323Code.GDRainObjects2.length = 0;
gdjs.lvl_323Code.GDSmokeObjects1.length = 0;
gdjs.lvl_323Code.GDSmokeObjects2.length = 0;
gdjs.lvl_323Code.GDPixiDustObjects1.length = 0;
gdjs.lvl_323Code.GDPixiDustObjects2.length = 0;
gdjs.lvl_323Code.GDSnowObjects1.length = 0;
gdjs.lvl_323Code.GDSnowObjects2.length = 0;
gdjs.lvl_323Code.GDSparksObjects1.length = 0;
gdjs.lvl_323Code.GDSparksObjects2.length = 0;
gdjs.lvl_323Code.GDTrailObjects1.length = 0;
gdjs.lvl_323Code.GDTrailObjects2.length = 0;
gdjs.lvl_323Code.GDVerticalBubblesObjects1.length = 0;
gdjs.lvl_323Code.GDVerticalBubblesObjects2.length = 0;
gdjs.lvl_323Code.GDLaserObjects1.length = 0;
gdjs.lvl_323Code.GDLaserObjects2.length = 0;
gdjs.lvl_323Code.GDTikTokObjects1.length = 0;
gdjs.lvl_323Code.GDTikTokObjects2.length = 0;
gdjs.lvl_323Code.GDWatermelonObjects1.length = 0;
gdjs.lvl_323Code.GDWatermelonObjects2.length = 0;
gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects1.length = 0;
gdjs.lvl_323Code.GDStrawberry_9595Ice_9595CreamObjects2.length = 0;
gdjs.lvl_323Code.GDTile_959515Objects1.length = 0;
gdjs.lvl_323Code.GDTile_959515Objects2.length = 0;
gdjs.lvl_323Code.GDdebrisObjects1.length = 0;
gdjs.lvl_323Code.GDdebrisObjects2.length = 0;
gdjs.lvl_323Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl_323Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl_323Code.GDBushObjects1.length = 0;
gdjs.lvl_323Code.GDBushObjects2.length = 0;
gdjs.lvl_323Code.GDScout_95952Objects1.length = 0;
gdjs.lvl_323Code.GDScout_95952Objects2.length = 0;
gdjs.lvl_323Code.GDTiny_9595grassObjects1.length = 0;
gdjs.lvl_323Code.GDTiny_9595grassObjects2.length = 0;


return;

}

gdjs['lvl_323Code'] = gdjs.lvl_323Code;
